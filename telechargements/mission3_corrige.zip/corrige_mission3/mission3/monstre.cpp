#include "monstre.h"

#include <QDebug>

Monstre::Monstre(QString nom, QString image, int x, int y, int vieMax, int force, int lenteur)
    : Personnage(nom, image, x, y, vieMax)
{
    m_force = force;
    m_lenteur = lenteur;
    qDebug() << "  Construction du monstre" << nom;
}

Monstre::~Monstre()
{
    qDebug() << "  Destruction du monstre" << nom();
}

int Monstre::force()
{
    return m_force;
}

// Vrai un tour sur m_lenteur : un monstre de lenteur 3 agit un tour sur trois.
bool Monstre::estPret(int numeroTour)
{
    return numeroTour % m_lenteur == 0;
}

// -1 si la cible est à gauche, +1 si elle est à droite, 0 si elle est dans la même colonne.
int Monstre::pasVersX(int cibleX)
{
    if (cibleX > m_x)
    {
        return 1;
    }
    if (cibleX < m_x)
    {
        return -1;
    }
    return 0;
}

// -1 si la cible est plus haut, +1 si elle est plus bas, 0 si elle est sur la même ligne.
int Monstre::pasVersY(int cibleY)
{
    if (cibleY > m_y)
    {
        return 1;
    }
    if (cibleY < m_y)
    {
        return -1;
    }
    return 0;
}
