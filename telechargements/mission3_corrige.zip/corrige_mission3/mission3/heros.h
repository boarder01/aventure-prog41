#ifndef HEROS_H
#define HEROS_H

#include "personnage.h"

// Le héros : un personnage qui possède en plus une bourse.

class Heros : public Personnage
{
public:
    Heros(QString nom = "Heros", int x = 1, int y = 1);
    ~Heros();

    void gagnerOr(int montant);
    int bourse();

private:
    int m_or;
};

#endif // HEROS_H
