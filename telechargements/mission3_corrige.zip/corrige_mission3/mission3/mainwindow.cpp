#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_heros("Aria", 4, 9)
    , m_villageois("Tom", 4, 4, "Bonjour ! Des slimes rôdent de l'autre côté du pont.")
{
    ui->setupUi(this);

    for (int i = 0; i < NB_MONSTRES; i++)
    {
        m_monstres[i] = Monstre("Slime", "slime", 13 + i, 10, 3, 1, 3);
    }

    m_pieceX[0] = 1;
    m_pieceY[0] = 1;
    m_pieceX[1] = 8;
    m_pieceY[1] = 2;
    m_pieceX[2] = 12;
    m_pieceY[2] = 1;
    for (int i = 0; i < NB_PIECES; i++)
    {
        m_piecePosee[i] = true;
    }

    connect(ui->jeu, SIGNAL(nouveauTour()), this, SLOT(tourDeJeu()));
    ui->jeu->demarrer();
}

MainWindow::~MainWindow()
{
    delete ui;
}

// Vrai si les deux cases se touchent par un côté.
bool MainWindow::voisines(int x1, int y1, int x2, int y2)
{
    return qAbs(x1 - x2) + qAbs(y1 - y2) == 1;
}

// Vrai si un personnage vivant se trouve déjà sur la case.
bool MainWindow::caseOccupee(int x, int y)
{
    if (x == m_heros.x() && y == m_heros.y())
    {
        return true;
    }
    if (x == m_villageois.x() && y == m_villageois.y())
    {
        return true;
    }
    for (int i = 0; i < NB_MONSTRES; i++)
    {
        if (m_monstres[i].estVivant() && x == m_monstres[i].x() && y == m_monstres[i].y())
        {
            return true;
        }
    }
    return false;
}

// Vrai si l'on peut entrer sur la case : la carte le permet et personne ne s'y trouve.
bool MainWindow::caseLibre(int x, int y)
{
    return ui->jeu->estLibre(x, y) && !caseOccupee(x, y);
}

void MainWindow::tourDeJeu()
{
    // ----- 1. Le héros : la case qu'il vise selon la touche enfoncée -----
    int viseX = m_heros.x();
    int viseY = m_heros.y();
    if (ui->jeu->touche(Qt::Key_Right))
    {
        viseX = viseX + 1;
    }
    else if (ui->jeu->touche(Qt::Key_Left))
    {
        viseX = viseX - 1;
    }
    else if (ui->jeu->touche(Qt::Key_Down))
    {
        viseY = viseY + 1;
    }
    else if (ui->jeu->touche(Qt::Key_Up))
    {
        viseY = viseY - 1;
    }

    bool aBouge = false;
    if ((viseX != m_heros.x() || viseY != m_heros.y())
            && ui->jeu->estLibre(viseX, viseY) && !caseOccupee(viseX, viseY))
    {
        m_heros.deplacer(viseX - m_heros.x(), viseY - m_heros.y());
        aBouge = true;
    }

    // ----- 2. Les pics blessent celui qui arrive dessus -----
    if (aBouge && ui->jeu->caseEn(m_heros.x(), m_heros.y()) == '^')
    {
        m_heros.recevoirDegats(2);
    }

    // ----- 3. Les pièces d'or -----
    for (int i = 0; i < NB_PIECES; i++)
    {
        if (m_piecePosee[i] && m_heros.x() == m_pieceX[i] && m_heros.y() == m_pieceY[i])
        {
            m_piecePosee[i] = false;
            m_heros.gagnerOr(5);
        }
    }

    // ----- 4. Les monstres : ils mordent le héros voisin, sinon ils s'en approchent -----
    for (int i = 0; i < NB_MONSTRES; i++)
    {
        if (m_monstres[i].estVivant())
        {
            if (voisines(m_monstres[i].x(), m_monstres[i].y(), m_heros.x(), m_heros.y()))
            {
                if (ui->jeu->numeroTour() % 6 == 0)
                {
                    m_heros.recevoirDegats(m_monstres[i].force());
                }
            }
            else if (m_monstres[i].estPret(ui->jeu->numeroTour()))
            {
                int pasX = m_monstres[i].pasVersX(m_heros.x());
                int pasY = m_monstres[i].pasVersY(m_heros.y());
                if (pasX != 0 && caseLibre(m_monstres[i].x() + pasX, m_monstres[i].y()))
                {
                    m_monstres[i].deplacer(pasX, 0);
                }
                else if (pasY != 0 && caseLibre(m_monstres[i].x(), m_monstres[i].y() + pasY))
                {
                    m_monstres[i].deplacer(0, pasY);
                }
            }
        }
    }

    // ----- 5. Le dessin : tout ce qui existe, à chaque tour -----
    for (int i = 0; i < NB_PIECES; i++)
    {
        if (m_piecePosee[i])
        {
            ui->jeu->dessiner("piece", m_pieceX[i], m_pieceY[i]);
        }
    }

    ui->jeu->dessiner(m_villageois.image(), m_villageois.x(), m_villageois.y());
    ui->jeu->ecrire(m_villageois.x(), m_villageois.y(), m_villageois.nom());

    for (int i = 0; i < NB_MONSTRES; i++)
    {
        if (m_monstres[i].estVivant())
        {
            ui->jeu->dessiner(m_monstres[i].image(), m_monstres[i].x(), m_monstres[i].y());
            ui->jeu->barreDeVie(m_monstres[i].x(), m_monstres[i].y(),
                                m_monstres[i].vie(), m_monstres[i].vieMax());
        }
    }

    ui->jeu->dessiner(m_heros.image(), m_heros.x(), m_heros.y());
    ui->jeu->barreDeVie(m_heros.x(), m_heros.y(), m_heros.vie(), m_heros.vieMax());

    ui->jeu->afficherInfos(QString("Vie : %1/%2").arg(m_heros.vie()).arg(m_heros.vieMax()));
    ui->jeu->afficherInfos(QString("Or : %1").arg(m_heros.bourse()));

    if (voisines(m_heros.x(), m_heros.y(), m_villageois.x(), m_villageois.y()))
    {
        ui->jeu->dire(m_villageois.parler());
    }
}
