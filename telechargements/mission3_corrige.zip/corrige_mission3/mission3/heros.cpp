#include "heros.h"

#include <QDebug>

// Le constructeur de la classe mère est appelé en premier, avec ses paramètres.
Heros::Heros(QString nom, int x, int y)
    : Personnage(nom, "heros", x, y, 10)
{
    m_or = 0;
    qDebug() << "  Construction du héros" << nom;
}

Heros::~Heros()
{
    qDebug() << "  Destruction du héros" << nom();
}

void Heros::gagnerOr(int montant)
{
    m_or = m_or + montant;
}

int Heros::bourse()
{
    return m_or;
}
