#ifndef VILLAGEOIS_H
#define VILLAGEOIS_H

#include "personnage.h"

// Le villageois : un personnage qui possède en plus une phrase à dire.

class Villageois : public Personnage
{
public:
    Villageois(QString nom = "Villageois", int x = 1, int y = 1, QString phrase = "Bonjour !");
    ~Villageois();

    QString parler();

private:
    QString m_phrase;
};

#endif // VILLAGEOIS_H
