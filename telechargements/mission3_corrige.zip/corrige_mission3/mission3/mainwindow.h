#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

#include "heros.h"
#include "monstre.h"
#include "villageois.h"

const int NB_MONSTRES = 4;
const int NB_PIECES = 3;

// Mission 3 : trois classes filles de Personnage.

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void tourDeJeu();       // appelé par le moteur à chaque tour de jeu

private:
    bool voisines(int x1, int y1, int x2, int y2);
    bool caseOccupee(int x, int y);
    bool caseLibre(int x, int y);

    Ui::MainWindow *ui;

    Heros m_heros;
    Villageois m_villageois;
    Monstre m_monstres[NB_MONSTRES];

    // Les pièces d'or : encore des variables en vrac, en attendant la classe Objet
    int m_pieceX[NB_PIECES];
    int m_pieceY[NB_PIECES];
    bool m_piecePosee[NB_PIECES];
};

#endif // MAINWINDOW_H
