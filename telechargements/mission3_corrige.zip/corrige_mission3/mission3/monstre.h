#ifndef MONSTRE_H
#define MONSTRE_H

#include "personnage.h"

// Le monstre : un personnage qui possède en plus une force et une lenteur.
// Tous les paramètres du constructeur ont une valeur par défaut : c'est
// indispensable pour déclarer un tableau de monstres.

class Monstre : public Personnage
{
public:
    Monstre(QString nom = "Monstre", QString image = "slime", int x = 1, int y = 1,
            int vieMax = 3, int force = 1, int lenteur = 3);
    ~Monstre();

    int force();
    bool estPret(int numeroTour);
    int pasVersX(int cibleX);
    int pasVersY(int cibleY);

private:
    int m_force;
    int m_lenteur;
};

#endif // MONSTRE_H
