# Corrigé de la mission 3 : Héros, villageois et monstres

QT += core gui widgets

TARGET = Aventure
TEMPLATE = app

SOURCES += \
    heros.cpp \
    main.cpp \
    mainwindow.cpp \
    monstre.cpp \
    personnage.cpp \
    villageois.cpp

HEADERS += \
    heros.h \
    mainwindow.h \
    monstre.h \
    personnage.h \
    villageois.h

FORMS += \
    mainwindow.ui

# Le moteur du jeu (livré, à ne pas modifier)
exists(../moteur/moteur.pri) {
    include(../moteur/moteur.pri)
} else:exists(../../moteur/moteur.pri) {
    include(../../moteur/moteur.pri)
} else {
    error("Dossier moteur introuvable : il doit se trouver a cote du dossier de ce projet.")
}
