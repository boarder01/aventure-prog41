#include "villageois.h"

#include <QDebug>

Villageois::Villageois(QString nom, int x, int y, QString phrase)
    : Personnage(nom, "villageois", x, y, 10)
{
    m_phrase = phrase;
    qDebug() << "  Construction du villageois" << nom;
}

Villageois::~Villageois()
{
    qDebug() << "  Destruction du villageois" << nom();
}

// La phrase du villageois, précédée de son nom : « Tom : Bonjour ! ».
QString Villageois::parler()
{
    return nom() + " : " + m_phrase;
}
