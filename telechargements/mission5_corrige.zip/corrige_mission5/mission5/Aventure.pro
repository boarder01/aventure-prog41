# Corrigé de la mission 5 : Chaque personnage se présente

QT += core gui widgets

TARGET = Aventure
TEMPLATE = app

SOURCES += \
    arme.cpp \
    chauvesouris.cpp \
    cle.cpp \
    guerisseur.cpp \
    guerrier.cpp \
    heros.cpp \
    mage.cpp \
    main.cpp \
    mainwindow.cpp \
    marchand.cpp \
    monstre.cpp \
    objet.cpp \
    objetutile.cpp \
    personnage.cpp \
    piece.cpp \
    potion.cpp \
    slime.cpp \
    squelette.cpp \
    villageois.cpp

HEADERS += \
    arme.h \
    chauvesouris.h \
    cle.h \
    guerisseur.h \
    guerrier.h \
    heros.h \
    mage.h \
    mainwindow.h \
    marchand.h \
    monstre.h \
    objet.h \
    objetutile.h \
    personnage.h \
    piece.h \
    potion.h \
    slime.h \
    squelette.h \
    villageois.h

FORMS += \
    mainwindow.ui

# Le moteur du jeu (livré, à ne pas modifier)
exists(../moteur/moteur.pri) {
    include(../moteur/moteur.pri)
} else:exists(../../moteur/moteur.pri) {
    include(../../moteur/moteur.pri)
} else {
    error("Dossier moteur introuvable : il doit se trouver a cote du dossier de ce projet.")
}
