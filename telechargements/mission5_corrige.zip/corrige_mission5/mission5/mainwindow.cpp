#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_heros("Aria", 4, 9)
    , m_marchand("Tom", 4, 4)
    , m_guerisseur("Lina", 7, 6)
    , m_chauveSouris(17, 11)
    , m_epee("Épée", "epee", 2, 8, 3)
    , m_cle(16, 2)
{
    ui->setupUi(this);

    m_slimes[0] = Slime(15, 10);
    m_slimes[1] = Slime(13, 9);
    m_squelettes[0] = Squelette(13, 3);
    m_squelettes[1] = Squelette(16, 5);       // enfermé dans les ruines, il garde le trésor

    m_potions[0] = Potion(8, 11);
    m_potions[1] = Potion(12, 1);
    m_pieces[0] = Piece(1, 1);
    m_pieces[1] = Piece(8, 2);
    m_pieces[2] = Piece(16, 6);               // le trésor des ruines

    m_criX = 0;
    m_criY = 0;
    m_criTours = 0;
    m_messageTours = 0;

    connect(ui->jeu, SIGNAL(nouveauTour()), this, SLOT(tourDeJeu()));
    connect(ui->jeu, SIGNAL(caseCliquee(int,int)), this, SLOT(caseCliquee(int,int)));
    ui->jeu->demarrer();
}

MainWindow::~MainWindow()
{
    delete ui;
}

// Vrai si les deux cases se touchent par un côté.
bool MainWindow::voisines(int x1, int y1, int x2, int y2)
{
    return qAbs(x1 - x2) + qAbs(y1 - y2) == 1;
}

// Vrai si un personnage vivant se trouve déjà sur la case.
bool MainWindow::caseOccupee(int x, int y)
{
    if (x == m_heros.x() && y == m_heros.y())
    {
        return true;
    }
    if (x == m_marchand.x() && y == m_marchand.y())
    {
        return true;
    }
    if (x == m_guerisseur.x() && y == m_guerisseur.y())
    {
        return true;
    }
    for (int i = 0; i < NB_SLIMES; i++)
    {
        if (m_slimes[i].estVivant() && x == m_slimes[i].x() && y == m_slimes[i].y())
        {
            return true;
        }
    }
    for (int i = 0; i < NB_SQUELETTES; i++)
    {
        if (m_squelettes[i].estVivant() && x == m_squelettes[i].x() && y == m_squelettes[i].y())
        {
            return true;
        }
    }
    if (m_chauveSouris.estVivant() && x == m_chauveSouris.x() && y == m_chauveSouris.y())
    {
        return true;
    }
    return false;
}

// Vrai si l'on peut entrer sur la case : la carte le permet et personne ne s'y trouve.
bool MainWindow::caseLibre(int x, int y)
{
    return ui->jeu->estLibre(x, y) && !caseOccupee(x, y);
}

// Retient le cri d'un monstre pour l'afficher au-dessus de lui pendant quelques tours.
void MainWindow::crier(QString cri, int x, int y)
{
    m_cri = cri;
    m_criX = x;
    m_criY = y;
    m_criTours = 4;
}

// Un clic sur une case : on cherche ce qui s'y trouve et on retient sa présentation.
void MainWindow::caseCliquee(int x, int y)
{
    QString texte;
    for (int i = 0; i < NB_POTIONS; i++)
    {
        if (m_potions[i].estSurLaCarte() && x == m_potions[i].x() && y == m_potions[i].y())
        {
            texte = m_potions[i].description();
        }
    }
    for (int i = 0; i < NB_PIECES; i++)
    {
        if (m_pieces[i].estSurLaCarte() && x == m_pieces[i].x() && y == m_pieces[i].y())
        {
            texte = m_pieces[i].description();
        }
    }
    if (m_cle.estSurLaCarte() && x == m_cle.x() && y == m_cle.y())
    {
        texte = m_cle.description();
    }
    if (m_epee.estSurLaCarte() && x == m_epee.x() && y == m_epee.y())
    {
        texte = m_epee.description();
    }
    if (x == m_marchand.x() && y == m_marchand.y())
    {
        texte = m_marchand.presentation();
    }
    if (x == m_guerisseur.x() && y == m_guerisseur.y())
    {
        texte = m_guerisseur.presentation();
    }
    for (int i = 0; i < NB_SLIMES; i++)
    {
        if (m_slimes[i].estVivant() && x == m_slimes[i].x() && y == m_slimes[i].y())
        {
            texte = m_slimes[i].presentation();
        }
    }
    for (int i = 0; i < NB_SQUELETTES; i++)
    {
        if (m_squelettes[i].estVivant() && x == m_squelettes[i].x() && y == m_squelettes[i].y())
        {
            texte = m_squelettes[i].presentation();
        }
    }
    if (m_chauveSouris.estVivant() && x == m_chauveSouris.x() && y == m_chauveSouris.y())
    {
        texte = m_chauveSouris.presentation();
    }
    if (x == m_heros.x() && y == m_heros.y())
    {
        texte = m_heros.presentation();
    }

    if (texte != "")
    {
        m_message = texte;
        m_messageTours = 20;
    }
}

void MainWindow::tourDeJeu()
{
    // ----- 1. Le héros : la case qu'il vise selon la touche enfoncée -----
    int viseX = m_heros.x();
    int viseY = m_heros.y();
    if (ui->jeu->touche(Qt::Key_Right))
    {
        viseX = viseX + 1;
    }
    else if (ui->jeu->touche(Qt::Key_Left))
    {
        viseX = viseX - 1;
    }
    else if (ui->jeu->touche(Qt::Key_Down))
    {
        viseY = viseY + 1;
    }
    else if (ui->jeu->touche(Qt::Key_Up))
    {
        viseY = viseY - 1;
    }

    bool aBouge = false;
    if ((viseX != m_heros.x() || viseY != m_heros.y())
            && ui->jeu->estLibre(viseX, viseY) && !caseOccupee(viseX, viseY))
    {
        m_heros.deplacer(viseX - m_heros.x(), viseY - m_heros.y());
        aBouge = true;
    }

    // ----- 2. Les pics blessent celui qui arrive dessus -----
    if (aBouge && ui->jeu->caseEn(m_heros.x(), m_heros.y()) == '^')
    {
        m_heros.recevoirDegats(2);
    }

    // ----- 3. Ce que le héros trouve sur sa case -----
    if (m_epee.estSurLaCarte() && m_heros.x() == m_epee.x() && m_heros.y() == m_epee.y())
    {
        m_heros.equiper(m_epee);        // le héros reçoit une copie de l'épée
        m_epee.ramasser();
    }
    for (int i = 0; i < NB_POTIONS; i++)
    {
        if (m_potions[i].estSurLaCarte()
                && m_heros.x() == m_potions[i].x() && m_heros.y() == m_potions[i].y())
        {
            m_heros.soigner(m_potions[i].points());
            m_potions[i].ramasser();
        }
    }
    if (m_cle.estSurLaCarte() && m_heros.x() == m_cle.x() && m_heros.y() == m_cle.y())
    {
        m_cle.ramasser();
    }
    for (int i = 0; i < NB_PIECES; i++)
    {
        if (m_pieces[i].estSurLaCarte()
                && m_heros.x() == m_pieces[i].x() && m_heros.y() == m_pieces[i].y())
        {
            m_heros.gagnerOr(m_pieces[i].points());
            m_pieces[i].ramasser();
        }
    }

    // ----- 4. La porte des ruines s'ouvre devant celui qui a ramassé la clé -----
    if (!m_cle.estSurLaCarte() && voisines(m_heros.x(), m_heros.y(), 14, 7))
    {
        ui->jeu->changerCase(14, 7, 'd');
    }

    // ----- 5. Le guérisseur soigne le héros voisin, un tour sur dix -----
    int tour = ui->jeu->numeroTour();
    bool presDuGuerisseur = voisines(m_heros.x(), m_heros.y(), m_guerisseur.x(), m_guerisseur.y());
    if (presDuGuerisseur && tour % 10 == 0)
    {
        m_heros.soigner(m_guerisseur.soin());
    }

    // ----- 6. Les monstres : le même code, recopié pour chaque tableau -----
    for (int i = 0; i < NB_SLIMES; i++)
    {
        if (m_slimes[i].estVivant())
        {
            if (voisines(m_slimes[i].x(), m_slimes[i].y(), m_heros.x(), m_heros.y()))
            {
                if (tour % 6 == 0)
                {
                    m_heros.recevoirDegats(m_slimes[i].force());
                    crier(m_slimes[i].cri(), m_slimes[i].x(), m_slimes[i].y());
                }
            }
            else if (m_slimes[i].estPret(tour))
            {
                int pasX = m_slimes[i].pasVersX(m_heros.x());
                int pasY = m_slimes[i].pasVersY(m_heros.y());
                if (pasX != 0 && caseLibre(m_slimes[i].x() + pasX, m_slimes[i].y()))
                {
                    m_slimes[i].deplacer(pasX, 0);
                }
                else if (pasY != 0 && caseLibre(m_slimes[i].x(), m_slimes[i].y() + pasY))
                {
                    m_slimes[i].deplacer(0, pasY);
                }
            }
        }
    }
    for (int i = 0; i < NB_SQUELETTES; i++)
    {
        if (m_squelettes[i].estVivant())
        {
            if (voisines(m_squelettes[i].x(), m_squelettes[i].y(), m_heros.x(), m_heros.y()))
            {
                if (tour % 6 == 0)
                {
                    m_heros.recevoirDegats(m_squelettes[i].force());
                    crier(m_squelettes[i].cri(), m_squelettes[i].x(), m_squelettes[i].y());
                }
            }
            else if (m_squelettes[i].estPret(tour))
            {
                int pasX = m_squelettes[i].pasVersX(m_heros.x());
                int pasY = m_squelettes[i].pasVersY(m_heros.y());
                if (pasX != 0 && caseLibre(m_squelettes[i].x() + pasX, m_squelettes[i].y()))
                {
                    m_squelettes[i].deplacer(pasX, 0);
                }
                else if (pasY != 0 && caseLibre(m_squelettes[i].x(), m_squelettes[i].y() + pasY))
                {
                    m_squelettes[i].deplacer(0, pasY);
                }
            }
        }
    }
    if (m_chauveSouris.estVivant())
    {
        if (voisines(m_chauveSouris.x(), m_chauveSouris.y(), m_heros.x(), m_heros.y()))
        {
            if (tour % 6 == 0)
            {
                m_heros.recevoirDegats(m_chauveSouris.force());
                crier(m_chauveSouris.cri(), m_chauveSouris.x(), m_chauveSouris.y());
            }
        }
        else if (m_chauveSouris.estPret(tour))
        {
            int pasX = m_chauveSouris.pasVersX(m_heros.x());
            int pasY = m_chauveSouris.pasVersY(m_heros.y());
            if (pasX != 0 && caseLibre(m_chauveSouris.x() + pasX, m_chauveSouris.y()))
            {
                m_chauveSouris.deplacer(pasX, 0);
            }
            else if (pasY != 0 && caseLibre(m_chauveSouris.x(), m_chauveSouris.y() + pasY))
            {
                m_chauveSouris.deplacer(0, pasY);
            }
        }
    }

    // ----- 7. Le dessin : les objets, les villageois, les monstres, puis le héros -----
    for (int i = 0; i < NB_POTIONS; i++)
    {
        if (m_potions[i].estSurLaCarte())
        {
            ui->jeu->dessiner(m_potions[i].image(), m_potions[i].x(), m_potions[i].y());
        }
    }
    for (int i = 0; i < NB_PIECES; i++)
    {
        if (m_pieces[i].estSurLaCarte())
        {
            ui->jeu->dessiner(m_pieces[i].image(), m_pieces[i].x(), m_pieces[i].y());
        }
    }
    if (m_cle.estSurLaCarte())
    {
        ui->jeu->dessiner(m_cle.image(), m_cle.x(), m_cle.y());
    }
    if (m_epee.estSurLaCarte())
    {
        ui->jeu->dessiner(m_epee.image(), m_epee.x(), m_epee.y());
    }

    ui->jeu->dessiner(m_marchand.image(), m_marchand.x(), m_marchand.y());
    ui->jeu->ecrire(m_marchand.x(), m_marchand.y(), m_marchand.nom());
    ui->jeu->dessiner(m_guerisseur.image(), m_guerisseur.x(), m_guerisseur.y());
    ui->jeu->ecrire(m_guerisseur.x(), m_guerisseur.y(), m_guerisseur.nom());

    for (int i = 0; i < NB_SLIMES; i++)
    {
        if (m_slimes[i].estVivant())
        {
            ui->jeu->dessiner(m_slimes[i].image(), m_slimes[i].x(), m_slimes[i].y());
            ui->jeu->barreDeVie(m_slimes[i].x(), m_slimes[i].y(), m_slimes[i].vie(), m_slimes[i].vieMax());
        }
    }
    for (int i = 0; i < NB_SQUELETTES; i++)
    {
        if (m_squelettes[i].estVivant())
        {
            ui->jeu->dessiner(m_squelettes[i].image(), m_squelettes[i].x(), m_squelettes[i].y());
            ui->jeu->barreDeVie(m_squelettes[i].x(), m_squelettes[i].y(), m_squelettes[i].vie(), m_squelettes[i].vieMax());
        }
    }
    if (m_chauveSouris.estVivant())
    {
        ui->jeu->dessiner(m_chauveSouris.image(), m_chauveSouris.x(), m_chauveSouris.y());
        ui->jeu->barreDeVie(m_chauveSouris.x(), m_chauveSouris.y(), m_chauveSouris.vie(), m_chauveSouris.vieMax());
    }

    ui->jeu->dessiner(m_heros.image(), m_heros.x(), m_heros.y());
    ui->jeu->barreDeVie(m_heros.x(), m_heros.y(), m_heros.vie(), m_heros.vieMax());

    if (m_criTours > 0)
    {
        ui->jeu->ecrire(m_criX, m_criY, m_cri);
        m_criTours = m_criTours - 1;
    }

    // ----- 8. Les textes -----
    ui->jeu->afficherInfos(QString("Vie : %1/%2").arg(m_heros.vie()).arg(m_heros.vieMax()));
    ui->jeu->afficherInfos(QString("Or : %1").arg(m_heros.bourse()));
    ui->jeu->afficherInfos("Arme : " + m_heros.arme().nom());

    if (voisines(m_heros.x(), m_heros.y(), m_marchand.x(), m_marchand.y()))
    {
        ui->jeu->dire(m_marchand.parler());
    }
    if (presDuGuerisseur)
    {
        ui->jeu->dire(m_guerisseur.parler());
    }
    if (m_messageTours > 0)
    {
        ui->jeu->dire(m_message);
        m_messageTours = m_messageTours - 1;
    }
}
