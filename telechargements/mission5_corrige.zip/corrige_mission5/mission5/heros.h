#ifndef HEROS_H
#define HEROS_H

#include "arme.h"
#include "personnage.h"

// Le héros : un personnage qui possède une bourse et une arme.
// L'arme est un attribut : elle est contenue dans le héros.

class Heros : public Personnage
{
public:
    Heros(QString nom = "Heros", QString image = "heros", int x = 1, int y = 1, int vieMax = 10);

    void gagnerOr(int montant);
    int bourse();

    void equiper(Arme arme);
    Arme arme();
    int degats();

private:
    int m_or;
    Arme m_arme;
};

#endif // HEROS_H
