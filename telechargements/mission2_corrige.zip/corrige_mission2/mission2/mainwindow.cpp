#include "mainwindow.h"
#include "ui_mainwindow.h"

// Les objets m_heros et m_villageois sont des attributs : leurs paramètres
// de construction se donnent dans la liste d'initialisation.
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_heros("Aria", "heros", 4, 9, 10)
    , m_villageois("Tom", "villageois", 4, 4, 10)
{
    ui->setupUi(this);

    // Chaque case du tableau a déjà été construite avec les valeurs par défaut.
    // On la remplace par un slime placé au bon endroit.
    for (int i = 0; i < NB_SLIMES; i++)
    {
        m_slimes[i] = Personnage("Slime", "slime", 13 + i, 10, 3);
    }

    connect(ui->jeu, SIGNAL(nouveauTour()), this, SLOT(tourDeJeu()));
    ui->jeu->demarrer();
}

MainWindow::~MainWindow()
{
    delete ui;
}

// Vrai si les deux cases se touchent par un côté.
bool MainWindow::voisines(int x1, int y1, int x2, int y2)
{
    return qAbs(x1 - x2) + qAbs(y1 - y2) == 1;
}

// Vrai si un personnage vivant se trouve déjà sur la case.
bool MainWindow::caseOccupee(int x, int y)
{
    if (x == m_heros.x() && y == m_heros.y())
    {
        return true;
    }
    if (x == m_villageois.x() && y == m_villageois.y())
    {
        return true;
    }
    for (int i = 0; i < NB_SLIMES; i++)
    {
        if (m_slimes[i].estVivant() && x == m_slimes[i].x() && y == m_slimes[i].y())
        {
            return true;
        }
    }
    return false;
}

// Vrai si l'on peut entrer sur la case : la carte le permet et personne ne s'y trouve.
bool MainWindow::caseLibre(int x, int y)
{
    return ui->jeu->estLibre(x, y) && !caseOccupee(x, y);
}

void MainWindow::tourDeJeu()
{
    // ----- 1. Le héros : la case qu'il vise selon la touche enfoncée -----
    int viseX = m_heros.x();
    int viseY = m_heros.y();
    if (ui->jeu->touche(Qt::Key_Right))
    {
        viseX = viseX + 1;
    }
    else if (ui->jeu->touche(Qt::Key_Left))
    {
        viseX = viseX - 1;
    }
    else if (ui->jeu->touche(Qt::Key_Down))
    {
        viseY = viseY + 1;
    }
    else if (ui->jeu->touche(Qt::Key_Up))
    {
        viseY = viseY - 1;
    }

    bool aBouge = false;
    if ((viseX != m_heros.x() || viseY != m_heros.y())
            && ui->jeu->estLibre(viseX, viseY) && !caseOccupee(viseX, viseY))
    {
        m_heros.deplacer(viseX - m_heros.x(), viseY - m_heros.y());
        aBouge = true;
    }

    // ----- 2. Les pics blessent celui qui arrive dessus -----
    if (aBouge && ui->jeu->caseEn(m_heros.x(), m_heros.y()) == '^')
    {
        m_heros.recevoirDegats(2);
    }

    // ----- 3. Les slimes : un tour sur trois, un pas vers le héros -----
    for (int i = 0; i < NB_SLIMES; i++)
    {
        bool voisin = voisines(m_slimes[i].x(), m_slimes[i].y(), m_heros.x(), m_heros.y());
        if (m_slimes[i].estVivant() && !voisin && ui->jeu->numeroTour() % 3 == 0)
        {
            int pasX = 0;
            int pasY = 0;
            if (m_heros.x() > m_slimes[i].x())
            {
                pasX = 1;
            }
            if (m_heros.x() < m_slimes[i].x())
            {
                pasX = -1;
            }
            if (m_heros.y() > m_slimes[i].y())
            {
                pasY = 1;
            }
            if (m_heros.y() < m_slimes[i].y())
            {
                pasY = -1;
            }

            if (pasX != 0 && caseLibre(m_slimes[i].x() + pasX, m_slimes[i].y()))
            {
                m_slimes[i].deplacer(pasX, 0);
            }
            else if (pasY != 0 && caseLibre(m_slimes[i].x(), m_slimes[i].y() + pasY))
            {
                m_slimes[i].deplacer(0, pasY);
            }
        }
    }

    // ----- 4. Un tour sur six, chaque slime voisin du héros le mord -----
    if (ui->jeu->numeroTour() % 6 == 0)
    {
        for (int i = 0; i < NB_SLIMES; i++)
        {
            if (m_slimes[i].estVivant()
                    && voisines(m_slimes[i].x(), m_slimes[i].y(), m_heros.x(), m_heros.y()))
            {
                m_heros.recevoirDegats(1);
            }
        }
    }

    // ----- 5. Le dessin : tout ce qui existe, à chaque tour -----
    ui->jeu->dessiner(m_villageois.image(), m_villageois.x(), m_villageois.y());
    ui->jeu->ecrire(m_villageois.x(), m_villageois.y(), m_villageois.nom());

    for (int i = 0; i < NB_SLIMES; i++)
    {
        if (m_slimes[i].estVivant())
        {
            ui->jeu->dessiner(m_slimes[i].image(), m_slimes[i].x(), m_slimes[i].y());
            ui->jeu->barreDeVie(m_slimes[i].x(), m_slimes[i].y(),
                                m_slimes[i].vie(), m_slimes[i].vieMax());
        }
    }

    ui->jeu->dessiner(m_heros.image(), m_heros.x(), m_heros.y());
    ui->jeu->barreDeVie(m_heros.x(), m_heros.y(), m_heros.vie(), m_heros.vieMax());

    ui->jeu->afficherInfos(QString("Vie : %1/%2").arg(m_heros.vie()).arg(m_heros.vieMax()));

    if (voisines(m_heros.x(), m_heros.y(), m_villageois.x(), m_villageois.y()))
    {
        ui->jeu->dire(m_villageois.nom() + " : Bonjour, voyageur !");
    }
}
