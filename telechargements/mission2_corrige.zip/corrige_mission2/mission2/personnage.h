#ifndef PERSONNAGE_H
#define PERSONNAGE_H

#include <QString>

// Un personnage du jeu : son nom, son image, sa case et ses points de vie.
// Le constructeur remplace la méthode definir : un personnage est complet
// dès sa déclaration.

class Personnage
{
public:
    Personnage(QString nom = "Inconnu", QString image = "villageois",
               int x = 1, int y = 1, int vieMax = 10);
    ~Personnage();

    void deplacer(int dx, int dy);
    void recevoirDegats(int degats);
    void soigner(int points);
    bool estVivant();

    QString nom();
    QString image();
    int x();
    int y();
    int vie();
    int vieMax();

private:
    QString m_nom;
    QString m_image;
    int m_x;
    int m_y;
    int m_vie;
    int m_vieMax;
};

#endif // PERSONNAGE_H
