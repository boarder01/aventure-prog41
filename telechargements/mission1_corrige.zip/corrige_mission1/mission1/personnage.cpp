#include "personnage.h"

// Donne au personnage son état de départ. La vie est placée au maximum.
void Personnage::definir(QString nom, QString image, int x, int y, int vieMax)
{
    m_nom = nom;
    m_image = image;
    m_x = x;
    m_y = y;
    m_vieMax = vieMax;
    m_vie = vieMax;
}

void Personnage::deplacer(int dx, int dy)
{
    m_x = m_x + dx;
    m_y = m_y + dy;
}

// La vie ne descend jamais sous zéro.
void Personnage::recevoirDegats(int degats)
{
    m_vie = m_vie - degats;
    if (m_vie < 0)
    {
        m_vie = 0;
    }
}

// La vie ne dépasse jamais le maximum.
void Personnage::soigner(int points)
{
    m_vie = m_vie + points;
    if (m_vie > m_vieMax)
    {
        m_vie = m_vieMax;
    }
}

bool Personnage::estVivant()
{
    return m_vie > 0;
}

QString Personnage::nom()
{
    return m_nom;
}

QString Personnage::image()
{
    return m_image;
}

int Personnage::x()
{
    return m_x;
}

int Personnage::y()
{
    return m_y;
}

int Personnage::vie()
{
    return m_vie;
}

int Personnage::vieMax()
{
    return m_vieMax;
}
