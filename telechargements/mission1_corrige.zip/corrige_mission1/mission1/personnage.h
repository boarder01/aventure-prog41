#ifndef PERSONNAGE_H
#define PERSONNAGE_H

#include <QString>

// Un personnage du jeu : son nom, son image, sa case et ses points de vie.
// Tous les attributs sont privés : on ne les atteint que par les méthodes.

class Personnage
{
public:
    void definir(QString nom, QString image, int x, int y, int vieMax);
    void deplacer(int dx, int dy);
    void recevoirDegats(int degats);
    void soigner(int points);
    bool estVivant();

    QString nom();
    QString image();
    int x();
    int y();
    int vie();
    int vieMax();

private:
    QString m_nom;
    QString m_image;
    int m_x;
    int m_y;
    int m_vie;
    int m_vieMax;
};

#endif // PERSONNAGE_H
