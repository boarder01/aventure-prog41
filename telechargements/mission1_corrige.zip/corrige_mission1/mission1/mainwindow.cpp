#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    m_heros.definir("Aria", "heros", 4, 9, 10);
    m_villageois.definir("Tom", "villageois", 4, 4, 10);
    m_slime.definir("Slime", "slime", 15, 10, 3);

    connect(ui->jeu, SIGNAL(nouveauTour()), this, SLOT(tourDeJeu()));
    ui->jeu->demarrer();
}

MainWindow::~MainWindow()
{
    delete ui;
}

// Vrai si les deux cases se touchent par un côté.
bool MainWindow::voisines(int x1, int y1, int x2, int y2)
{
    return qAbs(x1 - x2) + qAbs(y1 - y2) == 1;
}

// Vrai si quelqu'un se trouve déjà sur la case. La classe Personnage ne connaît
// ni la carte ni les autres personnages : c'est MainWindow qui arbitre.
bool MainWindow::caseOccupee(int x, int y)
{
    if (x == m_heros.x() && y == m_heros.y())
    {
        return true;
    }
    if (x == m_villageois.x() && y == m_villageois.y())
    {
        return true;
    }
    if (x == m_slime.x() && y == m_slime.y())
    {
        return true;
    }
    return false;
}

void MainWindow::tourDeJeu()
{
    // ----- 1. Le héros : la case qu'il vise selon la touche enfoncée -----
    int viseX = m_heros.x();
    int viseY = m_heros.y();
    if (ui->jeu->touche(Qt::Key_Right))
    {
        viseX = viseX + 1;
    }
    else if (ui->jeu->touche(Qt::Key_Left))
    {
        viseX = viseX - 1;
    }
    else if (ui->jeu->touche(Qt::Key_Down))
    {
        viseY = viseY + 1;
    }
    else if (ui->jeu->touche(Qt::Key_Up))
    {
        viseY = viseY - 1;
    }

    bool aBouge = false;
    if ((viseX != m_heros.x() || viseY != m_heros.y())
            && ui->jeu->estLibre(viseX, viseY) && !caseOccupee(viseX, viseY))
    {
        m_heros.deplacer(viseX - m_heros.x(), viseY - m_heros.y());
        aBouge = true;
    }

    // ----- 2. Les pics blessent celui qui arrive dessus -----
    if (aBouge && ui->jeu->caseEn(m_heros.x(), m_heros.y()) == '^')
    {
        m_heros.recevoirDegats(2);
    }

    // ----- 3. Le slime avance vers le héros, un tour sur trois -----
    if (ui->jeu->numeroTour() % 3 == 0)
    {
        int pasX = 0;
        int pasY = 0;
        if (m_heros.x() > m_slime.x())
        {
            pasX = 1;
        }
        if (m_heros.x() < m_slime.x())
        {
            pasX = -1;
        }
        if (m_heros.y() > m_slime.y())
        {
            pasY = 1;
        }
        if (m_heros.y() < m_slime.y())
        {
            pasY = -1;
        }

        // d'abord vers la gauche ou la droite ; si c'est impossible, vers le haut ou le bas
        if (pasX != 0 && ui->jeu->estLibre(m_slime.x() + pasX, m_slime.y())
                && !caseOccupee(m_slime.x() + pasX, m_slime.y()))
        {
            m_slime.deplacer(pasX, 0);
        }
        else if (pasY != 0 && ui->jeu->estLibre(m_slime.x(), m_slime.y() + pasY)
                 && !caseOccupee(m_slime.x(), m_slime.y() + pasY))
        {
            m_slime.deplacer(0, pasY);
        }
    }

    // ----- 4. Le dessin : tout ce qui existe, à chaque tour -----
    ui->jeu->dessiner(m_villageois.image(), m_villageois.x(), m_villageois.y());
    ui->jeu->ecrire(m_villageois.x(), m_villageois.y(), m_villageois.nom());

    ui->jeu->dessiner(m_slime.image(), m_slime.x(), m_slime.y());
    ui->jeu->barreDeVie(m_slime.x(), m_slime.y(), m_slime.vie(), m_slime.vieMax());

    ui->jeu->dessiner(m_heros.image(), m_heros.x(), m_heros.y());
    ui->jeu->barreDeVie(m_heros.x(), m_heros.y(), m_heros.vie(), m_heros.vieMax());

    ui->jeu->afficherInfos(QString("Vie : %1/%2").arg(m_heros.vie()).arg(m_heros.vieMax()));

    if (voisines(m_heros.x(), m_heros.y(), m_villageois.x(), m_villageois.y()))
    {
        ui->jeu->dire(m_villageois.nom() + " : Bonjour, voyageur !");
    }
}
