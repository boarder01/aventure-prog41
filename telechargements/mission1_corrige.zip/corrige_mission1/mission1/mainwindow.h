#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

#include "personnage.h"

// Mission 1 : les 11 variables de la mission 0 sont devenues 3 objets.

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void tourDeJeu();       // appelé par le moteur à chaque tour de jeu

private:
    bool voisines(int x1, int y1, int x2, int y2);
    bool caseOccupee(int x, int y);

    Ui::MainWindow *ui;

    Personnage m_heros;
    Personnage m_villageois;
    Personnage m_slime;
};

#endif // MAINWINDOW_H
