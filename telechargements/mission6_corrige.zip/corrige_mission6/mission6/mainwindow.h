#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

#include "chauvesouris.h"
#include "cle.h"
#include "guerisseur.h"
#include "guerrier.h"
#include "marchand.h"
#include "piece.h"
#include "potion.h"
#include "slime.h"
#include "squelette.h"

const int NB_SLIMES = 2;
const int NB_SQUELETTES = 2;
const int NB_POTIONS = 2;
const int NB_PIECES = 3;
const int NB_BUTIN = 5;

// Mission 6 : le combat. Les objets sont passés par référence : une seule fonction
// anime, dessine ou frappe n'importe quel monstre, quelle que soit sa classe.

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void tourDeJeu();       // appelé par le moteur à chaque tour de jeu
    void caseCliquee(int x, int y);

private:
    void placerTout();
    bool voisines(int x1, int y1, int x2, int y2);
    bool voisins(Personnage &a, Personnage &b);
    bool estSur(Personnage &personnage, int x, int y);
    bool estPose(Objet &objet, int x, int y);
    bool caseOccupee(int x, int y);
    bool caseLibre(int x, int y);

    void animer(Monstre &monstre, QString cri);
    bool frapper(Monstre &monstre);
    void laisserButin(int x, int y);
    void crier(QString cri, int x, int y);
    void dessinerMonstre(Monstre &monstre);
    void dessinerObjet(Objet &objet);

    Ui::MainWindow *ui;

    Guerrier m_heros;
    Marchand m_marchand;
    Guerisseur m_guerisseur;

    Slime m_slimes[NB_SLIMES];
    Squelette m_squelettes[NB_SQUELETTES];
    ChauveSouris m_chauveSouris;

    Arme m_epee;
    Potion m_potions[NB_POTIONS];
    Cle m_cle;
    Piece m_pieces[NB_PIECES];
    Piece m_butin[NB_BUTIN];        // les pièces que laissent les monstres vaincus

    // Le cri du dernier monstre qui a mordu, affiché pendant quelques tours
    QString m_cri;
    int m_criX;
    int m_criY;
    int m_criTours;

    // L'éclair du dernier coup porté par le héros
    int m_coupX;
    int m_coupY;
    int m_coupTours;

    // La présentation de ce que l'on vient de cliquer, affichée pendant vingt tours
    QString m_message;
    int m_messageTours;
};

#endif // MAINWINDOW_H
