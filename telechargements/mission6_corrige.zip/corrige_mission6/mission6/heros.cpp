#include "heros.h"

Heros::Heros(QString nom, QString image, int x, int y, int vieMax)
    : Personnage(nom, image, x, y, vieMax)
{
    m_or = 0;
}

void Heros::gagnerOr(int montant)
{
    m_or = m_or + montant;
}

int Heros::bourse()
{
    return m_or;
}

// L'arme est reçue par valeur : le héros en garde une copie.
void Heros::equiper(Arme arme)
{
    m_arme = arme;
}

Arme Heros::arme()
{
    return m_arme;
}

int Heros::degats()
{
    return m_arme.degats();
}

// La cible est reçue par référence : c'est bien le monstre d'origine qui est blessé.
// Par valeur, seule une copie perdrait des points de vie.
void Heros::attaquer(Monstre &cible)
{
    cible.recevoirDegats(degats());
}
