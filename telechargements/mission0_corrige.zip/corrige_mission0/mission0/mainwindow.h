#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

// Mission 0 : tout le jeu tient dans des variables en vrac.
// Comptez-les : 11 variables pour un héros, un villageois et un slime.

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void tourDeJeu();       // appelé par le moteur à chaque tour de jeu

private:
    bool voisines(int x1, int y1, int x2, int y2);
    bool caseOccupee(int x, int y);

    Ui::MainWindow *ui;

    // Le héros
    int m_herosX;
    int m_herosY;
    int m_herosVie;
    int m_herosVieMax;

    // Le villageois
    QString m_villageoisNom;
    int m_villageoisX;
    int m_villageoisY;

    // Le slime
    int m_slimeX;
    int m_slimeY;
    int m_slimeVie;
    int m_slimeVieMax;
};

#endif // MAINWINDOW_H
