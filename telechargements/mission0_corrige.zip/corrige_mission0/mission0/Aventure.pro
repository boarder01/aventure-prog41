# Corrigé de la mission 0 : Découverte du moteur

QT += core gui widgets

TARGET = Aventure
TEMPLATE = app

SOURCES += \
    main.cpp \
    mainwindow.cpp

HEADERS += \
    mainwindow.h

FORMS += \
    mainwindow.ui

# Le moteur du jeu (livré, à ne pas modifier)
exists(../moteur/moteur.pri) {
    include(../moteur/moteur.pri)
} else:exists(../../moteur/moteur.pri) {
    include(../../moteur/moteur.pri)
} else {
    error("Dossier moteur introuvable : il doit se trouver a cote du dossier de ce projet.")
}
