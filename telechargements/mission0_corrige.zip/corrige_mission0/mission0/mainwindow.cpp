#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    m_herosX = 4;
    m_herosY = 9;
    m_herosVieMax = 10;
    m_herosVie = m_herosVieMax;

    m_villageoisNom = "Tom";
    m_villageoisX = 4;
    m_villageoisY = 4;

    m_slimeX = 15;
    m_slimeY = 10;
    m_slimeVieMax = 3;
    m_slimeVie = m_slimeVieMax;

    connect(ui->jeu, SIGNAL(nouveauTour()), this, SLOT(tourDeJeu()));
    ui->jeu->demarrer();
}

MainWindow::~MainWindow()
{
    delete ui;
}

// Vrai si les deux cases se touchent par un côté.
bool MainWindow::voisines(int x1, int y1, int x2, int y2)
{
    return qAbs(x1 - x2) + qAbs(y1 - y2) == 1;
}

// Vrai si quelqu'un se trouve déjà sur la case. Le moteur connaît la carte,
// mais c'est à nous de savoir où sont nos personnages.
bool MainWindow::caseOccupee(int x, int y)
{
    if (x == m_herosX && y == m_herosY)
    {
        return true;
    }
    if (x == m_villageoisX && y == m_villageoisY)
    {
        return true;
    }
    if (x == m_slimeX && y == m_slimeY)
    {
        return true;
    }
    return false;
}

void MainWindow::tourDeJeu()
{
    // ----- 1. Le héros : la case qu'il vise selon la touche enfoncée -----
    int viseX = m_herosX;
    int viseY = m_herosY;
    if (ui->jeu->touche(Qt::Key_Right))
    {
        viseX = viseX + 1;
    }
    else if (ui->jeu->touche(Qt::Key_Left))
    {
        viseX = viseX - 1;
    }
    else if (ui->jeu->touche(Qt::Key_Down))
    {
        viseY = viseY + 1;
    }
    else if (ui->jeu->touche(Qt::Key_Up))
    {
        viseY = viseY - 1;
    }

    bool aBouge = false;
    if ((viseX != m_herosX || viseY != m_herosY)
            && ui->jeu->estLibre(viseX, viseY) && !caseOccupee(viseX, viseY))
    {
        m_herosX = viseX;
        m_herosY = viseY;
        aBouge = true;
    }

    // ----- 2. Les pics blessent celui qui arrive dessus -----
    if (aBouge && ui->jeu->caseEn(m_herosX, m_herosY) == '^')
    {
        m_herosVie = m_herosVie - 2;
        if (m_herosVie < 0)
        {
            m_herosVie = 0;
        }
    }

    // ----- 3. Le slime avance vers le héros, un tour sur trois -----
    if (ui->jeu->numeroTour() % 3 == 0)
    {
        int pasX = 0;
        int pasY = 0;
        if (m_herosX > m_slimeX)
        {
            pasX = 1;
        }
        if (m_herosX < m_slimeX)
        {
            pasX = -1;
        }
        if (m_herosY > m_slimeY)
        {
            pasY = 1;
        }
        if (m_herosY < m_slimeY)
        {
            pasY = -1;
        }

        // d'abord vers la gauche ou la droite ; si c'est impossible, vers le haut ou le bas
        if (pasX != 0 && ui->jeu->estLibre(m_slimeX + pasX, m_slimeY)
                && !caseOccupee(m_slimeX + pasX, m_slimeY))
        {
            m_slimeX = m_slimeX + pasX;
        }
        else if (pasY != 0 && ui->jeu->estLibre(m_slimeX, m_slimeY + pasY)
                 && !caseOccupee(m_slimeX, m_slimeY + pasY))
        {
            m_slimeY = m_slimeY + pasY;
        }
    }

    // ----- 4. Le dessin : tout ce qui existe, à chaque tour -----
    ui->jeu->dessiner("villageois", m_villageoisX, m_villageoisY);
    ui->jeu->ecrire(m_villageoisX, m_villageoisY, m_villageoisNom);

    ui->jeu->dessiner("slime", m_slimeX, m_slimeY);
    ui->jeu->barreDeVie(m_slimeX, m_slimeY, m_slimeVie, m_slimeVieMax);

    ui->jeu->dessiner("heros", m_herosX, m_herosY);
    ui->jeu->barreDeVie(m_herosX, m_herosY, m_herosVie, m_herosVieMax);

    ui->jeu->afficherInfos(QString("Vie : %1/%2").arg(m_herosVie).arg(m_herosVieMax));

    if (voisines(m_herosX, m_herosY, m_villageoisX, m_villageoisY))
    {
        ui->jeu->dire(m_villageoisNom + " : Bonjour, voyageur !");
    }
}
