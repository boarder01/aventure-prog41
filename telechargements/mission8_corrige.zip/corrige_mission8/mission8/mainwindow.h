#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

#include "chauvesouris.h"
#include "cle.h"
#include "forgeron.h"
#include "guerisseur.h"
#include "guerrier.h"
#include "marchand.h"
#include "piece.h"
#include "potion.h"
#include "slime.h"
#include "squelette.h"

const int NB_MONSTRES = 10;
const int NB_POTIONS = 2;
const int NB_PIECES = 3;
const int NB_BUTIN = 10;

// Mission 8 : les monstres sont des objets dynamiques, rangés dans un seul tableau
// de pointeurs sur la classe mère. Ils apparaissent (new) et disparaissent (delete).

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void tourDeJeu();       // appelé par le moteur à chaque tour de jeu
    void caseCliquee(int x, int y);

private:
    void placerTout();
    bool voisines(int x1, int y1, int x2, int y2);
    bool voisins(Personnage &a, Personnage &b);
    bool estSur(Personnage &personnage, int x, int y);
    bool estPose(Objet &objet, int x, int y);
    bool caseOccupee(int x, int y);
    bool caseLibre(int x, int y);

    void animer(Monstre &monstre);
    bool frapper(Monstre &monstre);
    void laisserButin(int x, int y);
    void crier(QString cri, int x, int y);
    void dessinerMonstre(Monstre &monstre);
    void dessinerObjet(Objet &objet);
    void prendre(Arme &arme, int ancienX, int ancienY);
    void apparaitre(Monstre *monstre);
    void viderMonstres();

    Ui::MainWindow *ui;

    Guerrier m_heros;
    Marchand m_marchand;
    Guerisseur m_guerisseur;
    Forgeron m_forgeron;

    // Tous les monstres, quelle que soit leur classe. nullptr : case libre.
    Monstre *m_monstres[NB_MONSTRES];
    int m_vaincus;

    Arme m_epee;
    Arme m_hache;
    Potion m_potions[NB_POTIONS];
    Cle m_cle;
    Piece m_pieces[NB_PIECES];
    Piece m_butin[NB_BUTIN];        // les pièces que laissent les monstres vaincus

    // Le cri du dernier monstre qui a mordu, affiché pendant quelques tours
    QString m_cri;
    int m_criX;
    int m_criY;
    int m_criTours;

    // L'éclair du dernier coup porté par le héros
    int m_coupX;
    int m_coupY;
    int m_coupTours;

    // La présentation de ce que l'on vient de cliquer, affichée pendant vingt tours
    QString m_message;
    int m_messageTours;
};

#endif // MAINWINDOW_H
