#ifndef PERSONNAGE_H
#define PERSONNAGE_H

#include <QString>

// La classe mère de tous les personnages du jeu.
// Elle est abstraite : la méthode virtuelle pure presentation interdit de créer
// un « personnage » tout court et oblige chaque classe concrète à se présenter.
// Le destructeur est virtuel : un monstre détruit à travers un pointeur sur sa
// classe mère appelle bien le destructeur de sa propre classe.

class Personnage
{
public:
    Personnage(QString nom = "Inconnu", QString image = "villageois",
               int x = 1, int y = 1, int vieMax = 10);
    virtual ~Personnage();

    void deplacer(int dx, int dy);
    void recevoirDegats(int degats);
    void soigner(int points);
    bool estVivant();

    QString nom();
    QString image();
    int x();
    int y();
    int vie();
    int vieMax();

    virtual QString presentation() = 0;

protected:
    int m_x;
    int m_y;

private:
    QString m_nom;
    QString m_image;
    int m_vie;
    int m_vieMax;
};

#endif // PERSONNAGE_H
