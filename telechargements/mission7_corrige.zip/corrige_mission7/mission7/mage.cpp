#include "mage.h"

Mage::Mage(QString nom, int x, int y)
    : Heros(nom, "mage", x, y, 8)
{
}

QString Mage::presentation()
{
    return QString("%1, mage, %2/%3 points de vie, %4 pièces d'or")
            .arg(nom()).arg(vie()).arg(vieMax()).arg(bourse());
}
