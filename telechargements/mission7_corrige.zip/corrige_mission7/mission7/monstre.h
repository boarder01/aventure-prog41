#ifndef MONSTRE_H
#define MONSTRE_H

#include "personnage.h"

// Le monstre : un personnage qui possède en plus une force et une lenteur.
// Chaque classe fille redéfinit la méthode cri.

class Monstre : public Personnage
{
public:
    Monstre(QString nom = "Monstre", QString image = "slime", int x = 1, int y = 1,
            int vieMax = 3, int force = 1, int lenteur = 3);

    int force();
    bool estPret(int numeroTour);
    int pasVersX(int cibleX);
    int pasVersY(int cibleY);
    QString cri();

    void attaquer(Personnage &cible);
    Monstre& plusDangereux(Monstre &autre);

private:
    int m_force;
    int m_lenteur;
};

#endif // MONSTRE_H
