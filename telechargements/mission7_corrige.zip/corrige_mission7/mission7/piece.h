#ifndef PIECE_H
#define PIECE_H

#include "objetutile.h"

// Une pièce vaut cinq pièces d'or.

class Piece : public ObjetUtile
{
public:
    Piece(int x = 0, int y = 0);
    QString description() override;
};

#endif // PIECE_H
