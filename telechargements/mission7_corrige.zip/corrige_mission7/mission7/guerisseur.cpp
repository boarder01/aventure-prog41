#include "guerisseur.h"

Guerisseur::Guerisseur(QString nom, int x, int y)
    : Villageois(nom, "guerisseur", x, y, "Approchez, je soigne les blessures.")
    , m_soin(1)
{
}

int Guerisseur::soin()
{
    return m_soin;
}

QString Guerisseur::presentation()
{
    return QString("%1, guérisseur : rend %2 point de vie à la fois").arg(nom()).arg(m_soin);
}
