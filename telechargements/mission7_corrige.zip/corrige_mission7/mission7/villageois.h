#ifndef VILLAGEOIS_H
#define VILLAGEOIS_H

#include "personnage.h"

// Le villageois : un personnage qui possède en plus une phrase à dire.
// Le constructeur reçoit maintenant l'image, que chaque classe fille choisit.

class Villageois : public Personnage
{
public:
    Villageois(QString nom = "Villageois", QString image = "villageois",
               int x = 1, int y = 1, QString phrase = "Bonjour !");

    QString parler();

private:
    QString m_phrase;
};

#endif // VILLAGEOIS_H
