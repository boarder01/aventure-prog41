#ifndef ARME_H
#define ARME_H

#include "objet.h"

// Une arme : un objet qui inflige des dégâts.
// Sans paramètre, le constructeur fabrique les « Poings », qui infligent un point.

class Arme : public Objet
{
public:
    Arme(QString nom = "Poings", QString image = "epee", int x = 0, int y = 0, int degats = 1);

    int degats();
    QString description() override;

private:
    int m_degats;
};

#endif // ARME_H
