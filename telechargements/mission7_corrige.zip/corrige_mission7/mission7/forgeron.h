#ifndef FORGERON_H
#define FORGERON_H

#include "arme.h"
#include "villageois.h"

// Le forgeron : un villageois qui a une arme à offrir.
// Comme le héros, il ne contient pas l'arme : il en garde l'adresse.

class Forgeron : public Villageois
{
public:
    Forgeron(QString nom = "Forgeron", int x = 1, int y = 1, Arme *arme = nullptr);

    Arme *donnerArme();
    QString presentation() override;

private:
    Arme *m_arme;       // nullptr quand le forgeron a donné son arme
};

#endif // FORGERON_H
