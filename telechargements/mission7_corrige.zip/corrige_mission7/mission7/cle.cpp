#include "cle.h"

Cle::Cle(int x, int y)
    : ObjetUtile("Clé", "cle", x, y, 0)
{
}

QString Cle::description()
{
    return "Clé : ouvre la porte des ruines";
}
