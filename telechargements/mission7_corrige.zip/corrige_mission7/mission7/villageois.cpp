#include "villageois.h"

Villageois::Villageois(QString nom, QString image, int x, int y, QString phrase)
    : Personnage(nom, image, x, y, 10)
{
    m_phrase = phrase;
}

// La phrase du villageois, précédée de son nom : « Tom : Bonjour ! ».
QString Villageois::parler()
{
    return nom() + " : " + m_phrase;
}
