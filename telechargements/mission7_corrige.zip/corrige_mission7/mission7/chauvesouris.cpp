#include "chauvesouris.h"

ChauveSouris::ChauveSouris(int x, int y)
    : Monstre("Chauve-souris", "chauve_souris", x, y, 2, 1, 1)
{
}

QString ChauveSouris::cri()
{
    return "Scriii !";
}

QString ChauveSouris::presentation()
{
    return QString("%1 (%2/%3)").arg("Chauve-souris : fragile, mais très rapide").arg(vie()).arg(vieMax());
}
