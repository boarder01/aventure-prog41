#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    placerTout();

    connect(ui->jeu, SIGNAL(nouveauTour()), this, SLOT(tourDeJeu()));
    connect(ui->jeu, SIGNAL(caseCliquee(int,int)), this, SLOT(caseCliquee(int,int)));
    ui->jeu->demarrer();
}

MainWindow::~MainWindow()
{
    delete ui;
}

// Met le jeu dans son état de départ. Sert au lancement, puis à chaque nouvelle partie.
void MainWindow::placerTout()
{
    ui->jeu->chargerCarte(":/moteur/cartes/village.txt");     // referme la porte des ruines

    m_heros = Guerrier("Aria", 4, 9);
    m_marchand = Marchand("Tom", 4, 4);
    m_guerisseur = Guerisseur("Lina", 7, 6);

    m_slimes[0] = Slime(15, 10);
    m_slimes[1] = Slime(13, 9);
    m_squelettes[0] = Squelette(13, 3);
    m_squelettes[1] = Squelette(16, 5);       // enfermé dans les ruines, il garde le trésor
    m_chauveSouris = ChauveSouris(17, 11);

    m_epee = Arme("Épée", "epee", 2, 8, 3);
    m_hache = Arme("Hache", "hache", 0, 0, 5);
    m_hache.ramasser();                       // elle n'est pas sur la carte : le forgeron la garde
    m_forgeron = Forgeron("Hugo", 2, 6, &m_hache);
    m_potions[0] = Potion(8, 11);
    m_potions[1] = Potion(12, 1);
    m_cle = Cle(16, 2);
    m_pieces[0] = Piece(1, 1);
    m_pieces[1] = Piece(8, 2);
    m_pieces[2] = Piece(16, 6);               // le trésor des ruines
    for (int i = 0; i < NB_BUTIN; i++)
    {
        m_butin[i] = Piece(0, 0);
        m_butin[i].ramasser();                // en réserve, hors de la carte
    }

    m_criTours = 0;
    m_coupTours = 0;
    m_messageTours = 0;
}

// Vrai si les deux cases se touchent par un côté.
bool MainWindow::voisines(int x1, int y1, int x2, int y2)
{
    return qAbs(x1 - x2) + qAbs(y1 - y2) == 1;
}

bool MainWindow::voisins(Personnage &a, Personnage &b)
{
    return voisines(a.x(), a.y(), b.x(), b.y());
}

// Vrai si le personnage est vivant et se trouve sur la case.
bool MainWindow::estSur(Personnage &personnage, int x, int y)
{
    return personnage.estVivant() && personnage.x() == x && personnage.y() == y;
}

// Vrai si l'objet est posé sur la carte, sur cette case.
bool MainWindow::estPose(Objet &objet, int x, int y)
{
    return objet.estSurLaCarte() && objet.x() == x && objet.y() == y;
}

// Vrai si un personnage vivant se trouve déjà sur la case.
bool MainWindow::caseOccupee(int x, int y)
{
    if (estSur(m_heros, x, y) || estSur(m_marchand, x, y) || estSur(m_guerisseur, x, y))
    {
        return true;
    }
    if (estSur(m_forgeron, x, y))
    {
        return true;
    }
    for (int i = 0; i < NB_SLIMES; i++)
    {
        if (estSur(m_slimes[i], x, y))
        {
            return true;
        }
    }
    for (int i = 0; i < NB_SQUELETTES; i++)
    {
        if (estSur(m_squelettes[i], x, y))
        {
            return true;
        }
    }
    return estSur(m_chauveSouris, x, y);
}

// Vrai si l'on peut entrer sur la case : la carte le permet et personne ne s'y trouve.
bool MainWindow::caseLibre(int x, int y)
{
    return ui->jeu->estLibre(x, y) && !caseOccupee(x, y);
}

// Un monstre mord le héros voisin, sinon il s'en approche.
// Le cri est fourni par l'appelant, qui connaît la classe exacte du monstre :
// à travers une référence sur Monstre, monstre.cri() appellerait toujours la
// version de la classe mère, tant que la méthode n'est pas virtuelle (mission 8).
void MainWindow::animer(Monstre &monstre, QString cri)
{
    if (!monstre.estVivant())
    {
        return;
    }

    int tour = ui->jeu->numeroTour();
    if (voisins(monstre, m_heros))
    {
        if (tour % 6 == 0)
        {
            monstre.attaquer(m_heros);
            crier(cri, monstre.x(), monstre.y());
        }
    }
    else if (monstre.estPret(tour))
    {
        int pasX = monstre.pasVersX(m_heros.x());
        int pasY = monstre.pasVersY(m_heros.y());
        if (pasX != 0 && caseLibre(monstre.x() + pasX, monstre.y()))
        {
            monstre.deplacer(pasX, 0);
        }
        else if (pasY != 0 && caseLibre(monstre.x(), monstre.y() + pasY))
        {
            monstre.deplacer(0, pasY);
        }
    }
}

// Le héros frappe ce monstre s'il est vivant et voisin. Retourne vrai si le coup est parti.
bool MainWindow::frapper(Monstre &monstre)
{
    if (!monstre.estVivant() || !voisins(m_heros, monstre))
    {
        return false;
    }

    m_heros.attaquer(monstre);
    m_coupX = monstre.x();
    m_coupY = monstre.y();
    m_coupTours = 2;
    if (!monstre.estVivant())
    {
        laisserButin(monstre.x(), monstre.y());
    }
    return true;
}

// Pose une pièce de la réserve sur la case où un monstre vient de tomber.
void MainWindow::laisserButin(int x, int y)
{
    for (int i = 0; i < NB_BUTIN; i++)
    {
        if (!m_butin[i].estSurLaCarte())
        {
            m_butin[i].poser(x, y);
            return;
        }
    }
}

// Retient le cri d'un monstre pour l'afficher au-dessus de lui pendant quelques tours.
void MainWindow::crier(QString cri, int x, int y)
{
    m_cri = cri;
    m_criX = x;
    m_criY = y;
    m_criTours = 4;
}

void MainWindow::dessinerMonstre(Monstre &monstre)
{
    if (monstre.estVivant())
    {
        ui->jeu->dessiner(monstre.image(), monstre.x(), monstre.y());
        ui->jeu->barreDeVie(monstre.x(), monstre.y(), monstre.vie(), monstre.vieMax());
    }
}

void MainWindow::dessinerObjet(Objet &objet)
{
    if (objet.estSurLaCarte())
    {
        ui->jeu->dessiner(objet.image(), objet.x(), objet.y());
    }
}

// Le héros s'équipe de l'arme sur laquelle il vient d'arriver. Celle qu'il portait
// est posée sur la case qu'il vient de quitter : aucun objet Arme n'est copié.
void MainWindow::prendre(Arme &arme, int ancienX, int ancienY)
{
    if (m_heros.arme() != nullptr)
    {
        m_heros.arme()->poser(ancienX, ancienY);
    }
    m_heros.equiper(&arme);
    arme.ramasser();
}

// Un clic sur une case : on cherche ce qui s'y trouve et on retient sa présentation.
// presentation et description sont virtuelles : la bonne version est appelée.
void MainWindow::caseCliquee(int x, int y)
{
    QString texte;
    if (estPose(m_epee, x, y))
    {
        texte = m_epee.description();
    }
    if (estPose(m_hache, x, y))
    {
        texte = m_hache.description();
    }
    if (estPose(m_cle, x, y))
    {
        texte = m_cle.description();
    }
    for (int i = 0; i < NB_POTIONS; i++)
    {
        if (estPose(m_potions[i], x, y))
        {
            texte = m_potions[i].description();
        }
    }
    for (int i = 0; i < NB_PIECES; i++)
    {
        if (estPose(m_pieces[i], x, y))
        {
            texte = m_pieces[i].description();
        }
    }
    for (int i = 0; i < NB_BUTIN; i++)
    {
        if (estPose(m_butin[i], x, y))
        {
            texte = m_butin[i].description();
        }
    }

    if (estSur(m_marchand, x, y))
    {
        texte = m_marchand.presentation();
    }
    if (estSur(m_guerisseur, x, y))
    {
        texte = m_guerisseur.presentation();
    }
    if (estSur(m_forgeron, x, y))
    {
        texte = m_forgeron.presentation();
    }
    for (int i = 0; i < NB_SLIMES; i++)
    {
        if (estSur(m_slimes[i], x, y))
        {
            texte = m_slimes[i].presentation();
        }
    }
    for (int i = 0; i < NB_SQUELETTES; i++)
    {
        if (estSur(m_squelettes[i], x, y))
        {
            texte = m_squelettes[i].presentation();
        }
    }
    if (estSur(m_chauveSouris, x, y))
    {
        texte = m_chauveSouris.presentation();
    }
    if (estSur(m_heros, x, y))
    {
        texte = m_heros.presentation();
    }

    if (texte != "")
    {
        m_message = texte;
        m_messageTours = 20;
    }
}

void MainWindow::tourDeJeu()
{
    int ancienX = m_heros.x();
    int ancienY = m_heros.y();

    // ----- 1. Le héros : la case qu'il vise selon la touche enfoncée -----
    int viseX = m_heros.x();
    int viseY = m_heros.y();
    if (ui->jeu->touche(Qt::Key_Right))
    {
        viseX = viseX + 1;
    }
    else if (ui->jeu->touche(Qt::Key_Left))
    {
        viseX = viseX - 1;
    }
    else if (ui->jeu->touche(Qt::Key_Down))
    {
        viseY = viseY + 1;
    }
    else if (ui->jeu->touche(Qt::Key_Up))
    {
        viseY = viseY - 1;
    }

    bool aBouge = false;
    if ((viseX != m_heros.x() || viseY != m_heros.y())
            && ui->jeu->estLibre(viseX, viseY) && !caseOccupee(viseX, viseY))
    {
        m_heros.deplacer(viseX - m_heros.x(), viseY - m_heros.y());
        aBouge = true;
    }

    // ----- 2. Les pics blessent celui qui arrive dessus -----
    if (aBouge && ui->jeu->caseEn(m_heros.x(), m_heros.y()) == '^')
    {
        m_heros.recevoirDegats(2);
    }

    // ----- 3. Ce que le héros trouve sur sa case -----
    if (aBouge && estPose(m_epee, m_heros.x(), m_heros.y()))
    {
        prendre(m_epee, ancienX, ancienY);
    }
    if (aBouge && estPose(m_hache, m_heros.x(), m_heros.y()))
    {
        prendre(m_hache, ancienX, ancienY);
    }
    for (int i = 0; i < NB_POTIONS; i++)
    {
        if (estPose(m_potions[i], m_heros.x(), m_heros.y()))
        {
            m_heros.soigner(m_potions[i].points());
            m_potions[i].ramasser();
        }
    }
    if (estPose(m_cle, m_heros.x(), m_heros.y()))
    {
        m_cle.ramasser();
    }
    for (int i = 0; i < NB_PIECES; i++)
    {
        if (estPose(m_pieces[i], m_heros.x(), m_heros.y()))
        {
            m_heros.gagnerOr(m_pieces[i].points());
            m_pieces[i].ramasser();
        }
    }
    for (int i = 0; i < NB_BUTIN; i++)
    {
        if (estPose(m_butin[i], m_heros.x(), m_heros.y()))
        {
            m_heros.gagnerOr(m_butin[i].points());
            m_butin[i].ramasser();
        }
    }

    // ----- 4. La porte des ruines s'ouvre devant celui qui a ramassé la clé -----
    if (!m_cle.estSurLaCarte() && voisines(m_heros.x(), m_heros.y(), 14, 7))
    {
        ui->jeu->changerCase(14, 7, 'd');
    }

    // ----- 5. Le guérisseur soigne le héros voisin, un tour sur dix -----
    int tour = ui->jeu->numeroTour();
    if (voisins(m_heros, m_guerisseur) && tour % 10 == 0)
    {
        m_heros.soigner(m_guerisseur.soin());
    }

    // ----- 6. La barre d'espace : le héros frappe un monstre voisin -----
    if (ui->jeu->toucheFrappee(Qt::Key_Space))
    {
        bool coupPorte = false;
        for (int i = 0; i < NB_SLIMES && !coupPorte; i++)
        {
            coupPorte = frapper(m_slimes[i]);
        }
        for (int i = 0; i < NB_SQUELETTES && !coupPorte; i++)
        {
            coupPorte = frapper(m_squelettes[i]);
        }
        if (!coupPorte)
        {
            coupPorte = frapper(m_chauveSouris);
        }

        // sinon, s'il est près du forgeron, il lui parle et reçoit son arme
        if (!coupPorte && voisins(m_heros, m_forgeron))
        {
            Arme *don = m_forgeron.donnerArme();
            if (don != nullptr)
            {
                if (m_heros.arme() != nullptr)
                {
                    m_heros.arme()->poser(m_heros.x(), m_heros.y());
                }
                m_heros.equiper(don);
            }
        }
    }

    // ----- 7. Les monstres : encore une boucle par tableau, mais une seule fonction -----
    for (int i = 0; i < NB_SLIMES; i++)
    {
        animer(m_slimes[i], m_slimes[i].cri());
    }
    for (int i = 0; i < NB_SQUELETTES; i++)
    {
        animer(m_squelettes[i], m_squelettes[i].cri());
    }
    animer(m_chauveSouris, m_chauveSouris.cri());

    // ----- Le dessin : les objets, les villageois, les monstres, puis le héros -----
    dessinerObjet(m_epee);
    dessinerObjet(m_hache);
    dessinerObjet(m_cle);
    for (int i = 0; i < NB_POTIONS; i++)
    {
        dessinerObjet(m_potions[i]);
    }
    for (int i = 0; i < NB_PIECES; i++)
    {
        dessinerObjet(m_pieces[i]);
    }
    for (int i = 0; i < NB_BUTIN; i++)
    {
        dessinerObjet(m_butin[i]);
    }

    ui->jeu->dessiner(m_marchand.image(), m_marchand.x(), m_marchand.y());
    ui->jeu->ecrire(m_marchand.x(), m_marchand.y(), m_marchand.nom());
    ui->jeu->dessiner(m_guerisseur.image(), m_guerisseur.x(), m_guerisseur.y());
    ui->jeu->ecrire(m_guerisseur.x(), m_guerisseur.y(), m_guerisseur.nom());
    ui->jeu->dessiner(m_forgeron.image(), m_forgeron.x(), m_forgeron.y());
    ui->jeu->ecrire(m_forgeron.x(), m_forgeron.y(), m_forgeron.nom());

    for (int i = 0; i < NB_SLIMES; i++)
    {
        dessinerMonstre(m_slimes[i]);
    }
    for (int i = 0; i < NB_SQUELETTES; i++)
    {
        dessinerMonstre(m_squelettes[i]);
    }
    dessinerMonstre(m_chauveSouris);

    // Le plus dangereux de deux monstres : la référence chef désigne l'un des deux.
    Monstre &chef = m_slimes[0].plusDangereux(m_squelettes[0]);
    if (chef.estVivant())
    {
        ui->jeu->ecrire(chef.x(), chef.y(), "!");
    }

    ui->jeu->dessiner(m_heros.image(), m_heros.x(), m_heros.y());
    ui->jeu->barreDeVie(m_heros.x(), m_heros.y(), m_heros.vie(), m_heros.vieMax());

    if (m_coupTours > 0)
    {
        ui->jeu->dessiner("coup", m_coupX, m_coupY);
        m_coupTours = m_coupTours - 1;
    }
    if (m_criTours > 0)
    {
        ui->jeu->ecrire(m_criX, m_criY, m_cri);
        m_criTours = m_criTours - 1;
    }

    // ----- Les textes -----
    ui->jeu->afficherInfos(QString("Vie : %1/%2").arg(m_heros.vie()).arg(m_heros.vieMax()));
    ui->jeu->afficherInfos(QString("Or : %1").arg(m_heros.bourse()));
    if (m_heros.arme() != nullptr)
    {
        ui->jeu->afficherInfos("Arme : " + m_heros.arme()->nom());
    }
    else
    {
        ui->jeu->afficherInfos("Arme : mains nues");
    }

    if (voisins(m_heros, m_marchand))
    {
        ui->jeu->dire(m_marchand.parler());
    }
    if (voisins(m_heros, m_guerisseur))
    {
        ui->jeu->dire(m_guerisseur.parler());
    }
    if (voisins(m_heros, m_forgeron))
    {
        ui->jeu->dire(m_forgeron.parler());
    }
    if (m_messageTours > 0)
    {
        ui->jeu->dire(m_message);
        m_messageTours = m_messageTours - 1;
    }

    // ----- La fin de partie -----
    if (!m_heros.estVivant())
    {
        QMessageBox::information(this, "Aventure", "Le héros est tombé... La partie recommence.");
        placerTout();
    }
}
