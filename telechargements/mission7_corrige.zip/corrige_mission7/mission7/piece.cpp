#include "piece.h"

Piece::Piece(int x, int y)
    : ObjetUtile("Pièce", "piece", x, y, 5)
{
}

QString Piece::description()
{
    return QString("Pièce : vaut %1 pièces d'or").arg(points());
}
