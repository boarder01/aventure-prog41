#include "arme.h"

Arme::Arme(QString nom, QString image, int x, int y, int degats)
    : Objet(nom, image, x, y)
{
    m_degats = degats;
}

int Arme::degats()
{
    return m_degats;
}

QString Arme::description()
{
    return QString("%1 : %2 point(s) de dégâts").arg(nom()).arg(m_degats);
}
