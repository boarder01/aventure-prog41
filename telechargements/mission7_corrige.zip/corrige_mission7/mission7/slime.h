#ifndef SLIME_H
#define SLIME_H

#include "monstre.h"

// Un monstre lent et faible.

class Slime : public Monstre
{
public:
    Slime(int x = 1, int y = 1);
    QString cri();
    QString presentation() override;
};

#endif // SLIME_H
