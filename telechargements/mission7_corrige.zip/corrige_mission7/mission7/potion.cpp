#include "potion.h"

Potion::Potion(int x, int y)
    : ObjetUtile("Potion", "potion", x, y, 5)
{
}

QString Potion::description()
{
    return QString("Potion : rend %1 points de vie").arg(points());
}
