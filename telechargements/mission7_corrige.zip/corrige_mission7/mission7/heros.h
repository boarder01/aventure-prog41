#ifndef HEROS_H
#define HEROS_H

#include "arme.h"
#include "monstre.h"
#include "personnage.h"

// Le héros : un personnage qui possède une bourse et une arme, et qui sait attaquer.
// L'arme n'est plus contenue dans le héros : m_arme est un pointeur sur une arme
// qui existe ailleurs. nullptr signifie que le héros se bat à mains nues.

class Heros : public Personnage
{
public:
    Heros(QString nom = "Heros", QString image = "heros", int x = 1, int y = 1, int vieMax = 10);

    void gagnerOr(int montant);
    int bourse();

    void equiper(Arme *arme);
    Arme *arme();
    int degats();

    void attaquer(Monstre &cible);

private:
    int m_or;
    Arme *m_arme;
};

#endif // HEROS_H
