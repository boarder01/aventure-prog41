#include "objetutile.h"

ObjetUtile::ObjetUtile(QString nom, QString image, int x, int y, int points)
    : Objet(nom, image, x, y)
{
    m_points = points;
}

int ObjetUtile::points()
{
    return m_points;
}
