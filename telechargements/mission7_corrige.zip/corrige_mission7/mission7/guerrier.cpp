#include "guerrier.h"

Guerrier::Guerrier(QString nom, int x, int y)
    : Heros(nom, "guerrier", x, y, 14)
{
}

QString Guerrier::presentation()
{
    return QString("%1, guerrier, %2/%3 points de vie, %4 pièces d'or")
            .arg(nom()).arg(vie()).arg(vieMax()).arg(bourse());
}
