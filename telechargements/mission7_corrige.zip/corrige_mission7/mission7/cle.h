#ifndef CLE_H
#define CLE_H

#include "objetutile.h"

// La clé ouvre la porte des ruines.

class Cle : public ObjetUtile
{
public:
    Cle(int x = 0, int y = 0);
    QString description() override;
};

#endif // CLE_H
