#ifndef MAGE_H
#define MAGE_H

#include "heros.h"

// Un héros fragile : 8 points de vie.

class Mage : public Heros
{
public:
    Mage(QString nom = "Mage", int x = 1, int y = 1);
    QString presentation() override;
};

#endif // MAGE_H
