#ifndef OBJETUTILE_H
#define OBJETUTILE_H

#include "objet.h"

// Un objet utile : un objet qui vaut un certain nombre de points
// (points de vie pour une potion, pièces d'or pour une pièce).

class ObjetUtile : public Objet
{
public:
    ObjetUtile(QString nom = "Objet utile", QString image = "coffre",
               int x = 0, int y = 0, int points = 0);

    int points();

private:
    int m_points;
};

#endif // OBJETUTILE_H
