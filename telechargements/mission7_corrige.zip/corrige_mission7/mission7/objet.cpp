#include "objet.h"

// Un objet est posé sur la carte dès sa création.
Objet::Objet(QString nom, QString image, int x, int y)
{
    m_nom = nom;
    m_image = image;
    m_x = x;
    m_y = y;
    m_surLaCarte = true;
}

bool Objet::estSurLaCarte()
{
    return m_surLaCarte;
}

void Objet::ramasser()
{
    m_surLaCarte = false;
}

void Objet::poser(int x, int y)
{
    m_x = x;
    m_y = y;
    m_surLaCarte = true;
}

QString Objet::nom()
{
    return m_nom;
}

QString Objet::image()
{
    return m_image;
}

int Objet::x()
{
    return m_x;
}

int Objet::y()
{
    return m_y;
}
