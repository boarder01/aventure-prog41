#ifndef CHAUVESOURIS_H
#define CHAUVESOURIS_H

#include "monstre.h"

// Le troisième monstre, inventé pour ce corrigé : fragile, mais très rapide.

class ChauveSouris : public Monstre
{
public:
    ChauveSouris(int x = 1, int y = 1);
    QString cri();
    QString presentation() override;
};

#endif // CHAUVESOURIS_H
