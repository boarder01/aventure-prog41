#ifndef GUERISSEUR_H
#define GUERISSEUR_H

#include "villageois.h"

// Le guérisseur : il rend des points de vie au héros qui se tient près de lui.

class Guerisseur : public Villageois
{
public:
    Guerisseur(QString nom = "Guerisseur", int x = 1, int y = 1);

    int soin();
    QString presentation() override;

private:
    int m_soin;
};

#endif // GUERISSEUR_H
