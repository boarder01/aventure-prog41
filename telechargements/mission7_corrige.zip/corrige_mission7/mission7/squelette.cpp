#include "squelette.h"

Squelette::Squelette(int x, int y)
    : Monstre("Squelette", "squelette", x, y, 6, 2, 2)
{
}

QString Squelette::cri()
{
    return "Clac clac !";
}

QString Squelette::presentation()
{
    return QString("%1 (%2/%3)").arg("Squelette : rapide et fort").arg(vie()).arg(vieMax());
}
