#ifndef POTION_H
#define POTION_H

#include "objetutile.h"

// Une potion rend cinq points de vie.

class Potion : public ObjetUtile
{
public:
    Potion(int x = 0, int y = 0);
    QString description() override;
};

#endif // POTION_H
