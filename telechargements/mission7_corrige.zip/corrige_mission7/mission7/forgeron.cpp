#include "forgeron.h"

Forgeron::Forgeron(QString nom, int x, int y, Arme *arme)
    : Villageois(nom, "forgeron", x, y,
                 "J'ai forgé une arme pour vous. Frappez la barre d'espace pour la recevoir.")
{
    m_arme = arme;
}

// Donne l'arme : le forgeron retourne son adresse et n'en garde aucune trace.
// L'objet Arme, lui, ne bouge pas et n'est pas copié.
Arme *Forgeron::donnerArme()
{
    Arme *arme = m_arme;
    m_arme = nullptr;
    return arme;
}

QString Forgeron::presentation()
{
    if (m_arme != nullptr)
    {
        return nom() + ", forgeron : il lui reste une arme à offrir";
    }
    return nom() + ", forgeron : il a déjà donné son arme";
}
