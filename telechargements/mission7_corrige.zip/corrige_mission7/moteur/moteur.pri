# Moteur du jeu d'aventure (cours Prog41).
# Pour l'utiliser dans un projet qmake, ajouter une seule ligne au fichier .pro :
#     include(../moteur/moteur.pri)

QT += widgets

INCLUDEPATH += $$PWD

HEADERS += $$PWD/zonejeu.h
SOURCES += $$PWD/zonejeu.cpp
RESOURCES += $$PWD/moteur.qrc
