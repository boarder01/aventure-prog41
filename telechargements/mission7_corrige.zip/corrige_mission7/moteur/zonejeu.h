#ifndef ZONEJEU_H
#define ZONEJEU_H

// ---------------------------------------------------------------------------
//  ZoneJeu : le moteur du jeu d'aventure (cours Prog41)
//
//  Ce fichier est LIVRÉ : il n'y a rien à modifier ici. Lisez seulement la
//  liste des fonctions ci-dessous, ce sont elles que votre programme appelle.
//
//  Principe : la carte est une grille de cases. La case (0, 0) est en haut à
//  gauche, x augmente vers la droite et y vers le bas.
//
//  Le moteur ne connaît pas vos personnages. À chaque tour de jeu, il efface
//  l'écran, redessine la carte puis émet le signal nouveauTour(). C'est à
//  vous, dans le slot relié à ce signal, de déplacer vos objets et de
//  redemander le dessin de tout ce qui doit être visible.
// ---------------------------------------------------------------------------

#include <QByteArray>
#include <QHash>
#include <QPixmap>
#include <QPoint>
#include <QSet>
#include <QString>
#include <QTimer>
#include <QVector>
#include <QWidget>

class QPainter;

class ZoneJeu : public QWidget
{
    Q_OBJECT

public:
    explicit ZoneJeu(QWidget *parent = nullptr);
    ~ZoneJeu() override;

    // ----- Le rythme du jeu ------------------------------------------------

    // Lance le jeu : le signal nouveauTour() est émis toutes les dureeTourMs
    // millisecondes (150 ms = un peu moins de 7 tours par seconde).
    void demarrer(int dureeTourMs = 150);

    // Met le jeu en pause : plus aucun tour n'est joué.
    void arreter();

    bool enMarche() const;

    // Numéro du tour en cours : 1, 2, 3... Pratique pour n'agir qu'un tour
    // sur trois : if (ui->jeu->numeroTour() % 3 == 0) ...
    int numeroTour() const;

    // ----- La carte --------------------------------------------------------
    //
    //  Une carte est un texte : une ligne par rangée, un symbole par case.
    //
    //     .  herbe            ,  fleurs           _  chemin
    //     s  sable            :  dalles           =  pont      |  pont vertical
    //     ^  pics             d  porte ouverte
    //        ... on peut marcher sur toutes les cases ci-dessus
    //
    //     #  mur              ~  eau              T  arbre
    //     R  rocher           M  maison           D  porte fermée
    //        ... ces cases-là bloquent le passage
    //
    //  Tout autre symbole est dessiné comme de l'herbe et laisse passer :
    //  c'est utile pour marquer une case spéciale que caseEn() retrouvera.

    // Charge une carte depuis un fichier texte. Retourne false si le fichier
    // est introuvable (la carte précédente est alors conservée).
    bool chargerCarte(const QString &fichier);

    // Définit la carte directement depuis un texte écrit dans le code.
    void definirCarte(const QString &texte);

    int nbColonnes() const;
    int nbLignes() const;

    // Vrai si la case (x, y) existe et que l'on peut marcher dessus.
    // Le moteur ne sait pas où sont vos personnages : il ne regarde que la carte.
    bool estLibre(int x, int y) const;

    // Symbole de la case (x, y), ou '\0' si la case est hors de la carte.
    char caseEn(int x, int y) const;

    // Remplace une case de la carte, par exemple pour ouvrir une porte :
    // ui->jeu->changerCase(14, 7, 'd');
    void changerCase(int x, int y, char symbole);

    // Ajoute votre propre type de case : son symbole, son image et si l'on
    // peut marcher dessus.
    void definirCase(char symbole, const QString &image, bool libre);

    // ----- Le clavier ------------------------------------------------------

    // Vrai tant que la touche est enfoncée. Exemple : touche(Qt::Key_Right).
    bool touche(Qt::Key laTouche);

    // Vrai pendant un seul tour à chaque nouvel appui, même si la touche
    // reste enfoncée. Idéal pour une action : attaquer, parler, ramasser.
    bool toucheFrappee(Qt::Key laTouche);

    // ----- Le dessin (à refaire à chaque tour) -----------------------------

    // Dessine une image sur la case (x, y). L'image est soit un nom fourni
    // par le moteur ("heros", "slime", "epee"... voir LISEZMOI), soit le
    // chemin d'un fichier image à vous.
    void dessiner(const QString &image, int x, int y);

    // Dessine une barre de vie au-dessus de la case (x, y).
    void barreDeVie(int x, int y, int vie, int vieMax);

    // Écrit un petit texte au-dessus de la case (x, y) : un nom, des dégâts...
    void ecrire(int x, int y, const QString &texte);

    // Affiche un texte dans la boîte de dialogue, en bas de l'écran.
    void dire(const QString &texte);

    // Affiche une ligne d'informations en haut de l'écran : vie, or, arme...
    void afficherInfos(const QString &texte);

    QSize sizeHint() const override;
    QSize minimumSizeHint() const override;

signals:
    // Émis à chaque tour de jeu. Reliez-le à votre slot :
    // connect(ui->jeu, SIGNAL(nouveauTour()), this, SLOT(tourDeJeu()));
    void nouveauTour();

    // Émis quand on clique sur une case de la carte.
    void caseCliquee(int x, int y);

protected:
    void paintEvent(QPaintEvent *evenement) override;
    void resizeEvent(QResizeEvent *evenement) override;
    void mousePressEvent(QMouseEvent *evenement) override;
    bool eventFilter(QObject *objet, QEvent *evenement) override;

private slots:
    void jouerUnTour();

private:
    struct TypeCase
    {
        QString image;
        bool libre;
    };

    struct Commande
    {
        enum Genre { Image, Barre, Texte };
        Genre genre;
        int x;
        int y;
        QString texte;   // nom de l'image ou texte à écrire
        int valeur;
        int maximum;
    };

    bool estDansCarte(int x, int y) const;
    void recalculerGeometrie();
    void construireFond();
    QPixmap imageSource(const QString &nom);
    QPixmap imageAjustee(const QString &nom);
    void ajouterCommande(Commande::Genre genre, int x, int y, const QString &texte,
                         int valeur = 0, int maximum = 0);
    void dessinerBarre(QPainter &peintre, const Commande &commande);
    void dessinerTexte(QPainter &peintre, const Commande &commande, const QRect &carte);
    void dessinerInfos(QPainter &peintre, const QRect &carte);
    void dessinerDialogue(QPainter &peintre, const QRect &carte);

    // La carte
    QVector<QByteArray> m_carte;
    int m_colonnes;
    int m_lignes;
    QHash<char, TypeCase> m_typesCases;

    // L'affichage
    int m_tailleCase;                      // côté d'une case à l'écran, en pixels
    QPoint m_origine;                      // coin haut gauche de la carte dans le widget
    QPixmap m_fond;                        // la carte déjà dessinée
    QHash<QString, QPixmap> m_sources;     // images telles que lues
    QHash<QString, QPixmap> m_ajustees;    // images à la taille d'une case
    QVector<Commande> m_commandes;         // ce qu'il faut dessiner ce tour-ci
    QString m_dialogue;
    QString m_infos;

    // Le rythme
    QTimer m_minuterie;
    int m_numeroTour;
    bool m_tourEnCours;

    // Le clavier
    QSet<int> m_enfoncees;                 // touches actuellement enfoncées
    QSet<int> m_frappes;                   // touches frappées depuis le dernier tour
    QSet<int> m_nouvelles;                 // nouveaux appuis depuis le dernier tour
};

#endif // ZONEJEU_H
