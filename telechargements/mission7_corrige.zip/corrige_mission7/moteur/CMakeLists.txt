# Moteur du jeu d'aventure (cours Prog41), pour un projet CMake avec Qt 6.
# Dans le CMakeLists.txt du projet, ajouter :
#     add_subdirectory(../moteur moteur)
#     target_link_libraries(MonProjet PRIVATE moteur)

find_package(Qt6 REQUIRED COMPONENTS Widgets)

add_library(moteur STATIC
    zonejeu.h
    zonejeu.cpp
    moteur.qrc
)
set_target_properties(moteur PROPERTIES AUTOMOC ON AUTORCC ON)
target_include_directories(moteur PUBLIC ${CMAKE_CURRENT_SOURCE_DIR})
target_link_libraries(moteur PUBLIC Qt6::Widgets)
