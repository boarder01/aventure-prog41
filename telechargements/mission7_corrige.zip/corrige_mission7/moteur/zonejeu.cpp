#include "zonejeu.h"

#include <QApplication>
#include <QDebug>
#include <QFile>
#include <QImage>
#include <QKeyEvent>
#include <QMouseEvent>
#include <QPainter>
#include <QStringList>

// Les images fournies font 16 x 16 pixels : une case à l'écran mesure un
// multiple de 16 pour que le pixel art reste net.
static const int TAILLE_IMAGE = 16;

// Au-delà, on considère que le programme a oublié de laisser le moteur
// effacer l'écran : on évite de remplir la mémoire.
static const int COMMANDES_MAX = 5000;

// Q_INIT_RESOURCE doit être appelé en dehors de tout espace de noms.
static void initialiserRessources()
{
    Q_INIT_RESOURCE(moteur);
}

// Image de remplacement, bien visible, quand un nom d'image est inconnu.
static QPixmap imageInconnue()
{
    QImage damier(TAILLE_IMAGE, TAILLE_IMAGE, QImage::Format_ARGB32);
    for (int y = 0; y < TAILLE_IMAGE; ++y) {
        for (int x = 0; x < TAILLE_IMAGE; ++x) {
            const bool clair = ((x / 4) + (y / 4)) % 2 == 0;
            damier.setPixel(x, y, clair ? qRgb(255, 0, 255) : qRgb(30, 30, 30));
        }
    }
    return QPixmap::fromImage(damier);
}

// Vrai si le widget qui a le clavier sert à saisir du texte ou une valeur :
// dans ce cas le moteur lui laisse les touches.
static bool saisitDuTexte(const QWidget *widget)
{
    return widget->inherits("QLineEdit") || widget->inherits("QTextEdit")
        || widget->inherits("QPlainTextEdit") || widget->inherits("QAbstractSpinBox")
        || widget->inherits("QComboBox");
}

ZoneJeu::ZoneJeu(QWidget *parent)
    : QWidget(parent)
    , m_colonnes(0)
    , m_lignes(0)
    , m_tailleCase(2 * TAILLE_IMAGE)
    , m_numeroTour(0)
    , m_tourEnCours(false)
{
    initialiserRessources();

    setFocusPolicy(Qt::StrongFocus);

    m_typesCases.insert('.', TypeCase{QStringLiteral("herbe"), true});
    m_typesCases.insert(',', TypeCase{QStringLiteral("fleurs"), true});
    m_typesCases.insert('_', TypeCase{QStringLiteral("chemin"), true});
    m_typesCases.insert('s', TypeCase{QStringLiteral("sable"), true});
    m_typesCases.insert(':', TypeCase{QStringLiteral("dalles"), true});
    m_typesCases.insert('=', TypeCase{QStringLiteral("pont"), true});
    m_typesCases.insert('|', TypeCase{QStringLiteral("pont_v"), true});
    m_typesCases.insert('^', TypeCase{QStringLiteral("pics"), true});
    m_typesCases.insert('d', TypeCase{QStringLiteral("porte_ouverte"), true});
    m_typesCases.insert('#', TypeCase{QStringLiteral("mur"), false});
    m_typesCases.insert('~', TypeCase{QStringLiteral("eau"), false});
    m_typesCases.insert('T', TypeCase{QStringLiteral("arbre"), false});
    m_typesCases.insert('R', TypeCase{QStringLiteral("rocher"), false});
    m_typesCases.insert('M', TypeCase{QStringLiteral("maison"), false});
    m_typesCases.insert('D', TypeCase{QStringLiteral("porte"), false});

    chargerCarte(QStringLiteral(":/moteur/cartes/village.txt"));

    connect(&m_minuterie, &QTimer::timeout, this, &ZoneJeu::jouerUnTour);

    // Le moteur écoute le clavier de toute la fenêtre : le jeu continue de
    // répondre même après un clic sur un bouton.
    qApp->installEventFilter(this);
}

ZoneJeu::~ZoneJeu()
{
    if (qApp)
        qApp->removeEventFilter(this);
}

// ---------------------------------------------------------------------------
//  Le rythme du jeu
// ---------------------------------------------------------------------------

void ZoneJeu::demarrer(int dureeTourMs)
{
    m_minuterie.start(qMax(10, dureeTourMs));
    setFocus();
}

void ZoneJeu::arreter()
{
    m_minuterie.stop();
}

bool ZoneJeu::enMarche() const
{
    return m_minuterie.isActive();
}

int ZoneJeu::numeroTour() const
{
    return m_numeroTour;
}

void ZoneJeu::jouerUnTour()
{
    // Si le tour précédent n'est pas terminé (une boîte de message est
    // ouverte dans le slot, par exemple), on attend.
    if (m_tourEnCours)
        return;

    m_tourEnCours = true;
    ++m_numeroTour;

    m_commandes.clear();
    m_dialogue.clear();
    m_infos.clear();

    emit nouveauTour();

    m_frappes.clear();
    m_nouvelles.clear();
    m_tourEnCours = false;

    update();
}

// ---------------------------------------------------------------------------
//  La carte
// ---------------------------------------------------------------------------

bool ZoneJeu::chargerCarte(const QString &fichier)
{
    QFile lecture(fichier);
    if (!lecture.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qWarning().noquote() << "ZoneJeu : impossible d'ouvrir la carte" << fichier;
        return false;
    }
    definirCarte(QString::fromUtf8(lecture.readAll()));
    return true;
}

void ZoneJeu::definirCarte(const QString &texte)
{
    QVector<QByteArray> lignes;
    int largeur = 0;

    const QStringList morceaux = texte.split(QLatin1Char('\n'));
    for (QString ligne : morceaux) {
        while (!ligne.isEmpty() && ligne.at(ligne.size() - 1).isSpace())
            ligne.chop(1);
        if (ligne.isEmpty() && lignes.isEmpty())
            continue;   // lignes vides avant la carte
        lignes.append(ligne.toLatin1());
        largeur = qMax(largeur, int(ligne.size()));
    }
    while (!lignes.isEmpty() && lignes.last().isEmpty())
        lignes.removeLast();

    // Toutes les rangées ont la même largeur : on complète avec de l'herbe.
    for (QByteArray &ligne : lignes) {
        ligne.replace(' ', '.');
        if (ligne.size() < largeur)
            ligne.append(QByteArray(largeur - int(ligne.size()), '.'));
    }

    m_carte = lignes;
    m_colonnes = largeur;
    m_lignes = int(lignes.size());

    recalculerGeometrie();
    updateGeometry();
    update();
}

int ZoneJeu::nbColonnes() const
{
    return m_colonnes;
}

int ZoneJeu::nbLignes() const
{
    return m_lignes;
}

bool ZoneJeu::estDansCarte(int x, int y) const
{
    return x >= 0 && y >= 0 && x < m_colonnes && y < m_lignes;
}

bool ZoneJeu::estLibre(int x, int y) const
{
    if (!estDansCarte(x, y))
        return false;
    const QHash<char, TypeCase>::const_iterator type = m_typesCases.constFind(m_carte.at(y).at(x));
    return type == m_typesCases.constEnd() || type->libre;
}

char ZoneJeu::caseEn(int x, int y) const
{
    return estDansCarte(x, y) ? m_carte.at(y).at(x) : '\0';
}

void ZoneJeu::changerCase(int x, int y, char symbole)
{
    if (!estDansCarte(x, y) || m_carte.at(y).at(x) == symbole)
        return;
    m_carte[y][x] = symbole;
    m_fond = QPixmap();
    update();
}

void ZoneJeu::definirCase(char symbole, const QString &image, bool libre)
{
    m_typesCases.insert(symbole, TypeCase{image, libre});
    m_fond = QPixmap();
    update();
}

// ---------------------------------------------------------------------------
//  Le clavier
// ---------------------------------------------------------------------------

bool ZoneJeu::touche(Qt::Key laTouche)
{
    // Une touche frappée très brièvement entre deux tours compte pour un tour.
    if (m_tourEnCours)
        return m_enfoncees.contains(laTouche) || m_frappes.contains(laTouche);

    // Hors d'un tour de jeu, la frappe mémorisée ne sert qu'une fois.
    const bool frappee = m_frappes.remove(laTouche);
    return frappee || m_enfoncees.contains(laTouche);
}

bool ZoneJeu::toucheFrappee(Qt::Key laTouche)
{
    if (m_tourEnCours)
        return m_nouvelles.contains(laTouche);
    return m_nouvelles.remove(laTouche);
}

bool ZoneJeu::eventFilter(QObject *objet, QEvent *evenement)
{
    const QEvent::Type type = evenement->type();

    // La fenêtre passe à l'arrière-plan : on ne recevra pas les relâchements.
    if (type == QEvent::WindowDeactivate && objet == window()) {
        m_enfoncees.clear();
        m_frappes.clear();
        m_nouvelles.clear();
        return false;
    }

    if (type != QEvent::KeyPress && type != QEvent::KeyRelease)
        return false;
    if (!objet->isWidgetType() || !isVisible())
        return false;

    const QWidget *cible = static_cast<const QWidget *>(objet);
    if (cible->window() != window())
        return false;

    const QKeyEvent *clavier = static_cast<const QKeyEvent *>(evenement);
    const int code = clavier->key();

    if (type == QEvent::KeyRelease && !clavier->isAutoRepeat())
        m_enfoncees.remove(code);

    // Raccourcis (Ctrl+Q, Alt+F4...), tabulation et champs de saisie : on
    // laisse Qt faire son travail habituel.
    if (clavier->modifiers() & (Qt::ControlModifier | Qt::AltModifier | Qt::MetaModifier))
        return false;
    if (code == Qt::Key_Tab || code == Qt::Key_Backtab)
        return false;
    if (saisitDuTexte(cible))
        return false;

    if (type == QEvent::KeyPress && !clavier->isAutoRepeat()) {
        m_enfoncees.insert(code);
        m_frappes.insert(code);
        m_nouvelles.insert(code);
    }
    return true;
}

// ---------------------------------------------------------------------------
//  Le dessin
// ---------------------------------------------------------------------------

void ZoneJeu::ajouterCommande(Commande::Genre genre, int x, int y, const QString &texte,
                              int valeur, int maximum)
{
    if (m_commandes.size() >= COMMANDES_MAX)
        m_commandes.remove(0, COMMANDES_MAX / 2);
    m_commandes.append(Commande{genre, x, y, texte, valeur, maximum});
    update();
}

void ZoneJeu::dessiner(const QString &image, int x, int y)
{
    ajouterCommande(Commande::Image, x, y, image);
}

void ZoneJeu::barreDeVie(int x, int y, int vie, int vieMax)
{
    ajouterCommande(Commande::Barre, x, y, QString(), vie, vieMax);
}

void ZoneJeu::ecrire(int x, int y, const QString &texte)
{
    ajouterCommande(Commande::Texte, x, y, texte);
}

void ZoneJeu::dire(const QString &texte)
{
    if (!m_dialogue.isEmpty())
        m_dialogue += QLatin1Char('\n');
    m_dialogue += texte;
    update();
}

void ZoneJeu::afficherInfos(const QString &texte)
{
    if (!m_infos.isEmpty())
        m_infos += QStringLiteral("    ");
    m_infos += texte;
    update();
}

QSize ZoneJeu::sizeHint() const
{
    return QSize(qMax(1, m_colonnes) * 2 * TAILLE_IMAGE, qMax(1, m_lignes) * 2 * TAILLE_IMAGE);
}

QSize ZoneJeu::minimumSizeHint() const
{
    return QSize(qMax(1, m_colonnes) * TAILLE_IMAGE, qMax(1, m_lignes) * TAILLE_IMAGE);
}

void ZoneJeu::resizeEvent(QResizeEvent *evenement)
{
    QWidget::resizeEvent(evenement);
    recalculerGeometrie();
}

void ZoneJeu::recalculerGeometrie()
{
    const int colonnes = qMax(1, m_colonnes);
    const int lignes = qMax(1, m_lignes);

    // Le plus grand agrandissement entier qui tient dans le widget.
    const int agrandissement = qMin(width() / (colonnes * TAILLE_IMAGE),
                                    height() / (lignes * TAILLE_IMAGE));
    if (agrandissement >= 1)
        m_tailleCase = agrandissement * TAILLE_IMAGE;
    else
        m_tailleCase = qMax(4, qMin(width() / colonnes, height() / lignes));

    m_origine = QPoint((width() - colonnes * m_tailleCase) / 2,
                       (height() - lignes * m_tailleCase) / 2);

    m_ajustees.clear();
    m_fond = QPixmap();
}

QPixmap ZoneJeu::imageSource(const QString &nom)
{
    const QHash<QString, QPixmap>::const_iterator connue = m_sources.constFind(nom);
    if (connue != m_sources.constEnd())
        return connue.value();

    QPixmap image(QStringLiteral(":/moteur/images/") + nom + QStringLiteral(".png"));
    if (image.isNull())
        image.load(nom);
    if (image.isNull()) {
        qWarning().noquote() << "ZoneJeu : image introuvable :" << nom;
        image = imageInconnue();
    }
    m_sources.insert(nom, image);
    return image;
}

QPixmap ZoneJeu::imageAjustee(const QString &nom)
{
    const QHash<QString, QPixmap>::const_iterator connue = m_ajustees.constFind(nom);
    if (connue != m_ajustees.constEnd())
        return connue.value();

    const QPixmap source = imageSource(nom);
    const Qt::TransformationMode mode = source.width() <= 4 * TAILLE_IMAGE
            ? Qt::FastTransformation : Qt::SmoothTransformation;
    const QPixmap ajustee = source.scaled(m_tailleCase, m_tailleCase, Qt::IgnoreAspectRatio, mode);
    m_ajustees.insert(nom, ajustee);
    return ajustee;
}

void ZoneJeu::construireFond()
{
    if (m_colonnes == 0 || m_lignes == 0) {
        m_fond = QPixmap();
        return;
    }

    m_fond = QPixmap(m_colonnes * m_tailleCase, m_lignes * m_tailleCase);
    m_fond.fill(Qt::black);

    QPainter peintre(&m_fond);
    for (int y = 0; y < m_lignes; ++y) {
        for (int x = 0; x < m_colonnes; ++x) {
            const QPoint coin(x * m_tailleCase, y * m_tailleCase);

            // L'herbe d'abord, avec quelques variantes pour éviter la répétition.
            const int variante = (x * 7 + y * 13 + x * y) % 6;
            QString sol = QStringLiteral("herbe");
            if (variante == 1)
                sol = QStringLiteral("herbe2");
            else if (variante == 4)
                sol = QStringLiteral("herbe3");
            peintre.drawPixmap(coin, imageAjustee(sol));

            // Puis ce que la case contient.
            const QHash<char, TypeCase>::const_iterator type = m_typesCases.constFind(m_carte.at(y).at(x));
            if (type != m_typesCases.constEnd() && type->image != QLatin1String("herbe"))
                peintre.drawPixmap(coin, imageAjustee(type->image));
        }
    }
}

void ZoneJeu::paintEvent(QPaintEvent *)
{
    QPainter peintre(this);
    peintre.fillRect(rect(), QColor(24, 26, 36));

    if (m_colonnes == 0 || m_lignes == 0)
        return;
    if (m_fond.isNull())
        construireFond();

    const QRect carte(m_origine, m_fond.size());
    peintre.setClipRect(carte);
    peintre.drawPixmap(m_origine, m_fond);

    // Les images d'abord, puis les barres de vie, puis les textes : ainsi un
    // texte n'est jamais caché par un personnage dessiné après lui.
    for (const Commande &commande : m_commandes) {
        if (commande.genre == Commande::Image) {
            peintre.drawPixmap(m_origine.x() + commande.x * m_tailleCase,
                               m_origine.y() + commande.y * m_tailleCase,
                               imageAjustee(commande.texte));
        }
    }
    for (const Commande &commande : m_commandes) {
        if (commande.genre == Commande::Barre)
            dessinerBarre(peintre, commande);
    }
    for (const Commande &commande : m_commandes) {
        if (commande.genre == Commande::Texte)
            dessinerTexte(peintre, commande, carte);
    }

    if (!m_infos.isEmpty())
        dessinerInfos(peintre, carte);
    if (!m_dialogue.isEmpty())
        dessinerDialogue(peintre, carte);
}

void ZoneJeu::dessinerBarre(QPainter &peintre, const Commande &commande)
{
    if (commande.maximum <= 0)
        return;

    const int marge = m_tailleCase / 8;
    const int hauteur = qMax(4, m_tailleCase / 8);
    const QRect cadre(m_origine.x() + commande.x * m_tailleCase + marge,
                      m_origine.y() + commande.y * m_tailleCase - hauteur + m_tailleCase / 16,
                      m_tailleCase - 2 * marge, hauteur);

    const int vie = qBound(0, commande.valeur, commande.maximum);
    QColor couleur(76, 175, 80);            // vert
    if (4 * vie <= commande.maximum)
        couleur = QColor(217, 67, 63);      // rouge : un quart ou moins
    else if (2 * vie <= commande.maximum)
        couleur = QColor(240, 160, 48);     // orange : la moitié ou moins

    peintre.fillRect(cadre, QColor(27, 27, 38));
    const QRect interieur = cadre.adjusted(1, 1, -1, -1);
    const int rempli = interieur.width() * vie / commande.maximum;
    peintre.fillRect(QRect(interieur.left(), interieur.top(), rempli, interieur.height()), couleur);
}

void ZoneJeu::dessinerTexte(QPainter &peintre, const Commande &commande, const QRect &carte)
{
    QFont police = font();
    police.setBold(true);
    police.setPixelSize(qMax(10, m_tailleCase * 3 / 8));
    peintre.setFont(police);

    const QFontMetrics mesure = peintre.fontMetrics();
    const int largeur = mesure.horizontalAdvance(commande.texte) + 4;
    const int hauteur = mesure.height();

    // Centré sur la case, au-dessus de la barre de vie, sans sortir de la carte.
    int gauche = m_origine.x() + commande.x * m_tailleCase + (m_tailleCase - largeur) / 2;
    int haut = m_origine.y() + commande.y * m_tailleCase - hauteur - qMax(4, m_tailleCase / 8);
    gauche = qMax(carte.left(), qMin(gauche, carte.right() - largeur + 1));
    haut = qMax(carte.top(), haut);

    const QRect cadre(gauche, haut, largeur, hauteur);
    const int options = Qt::AlignCenter | Qt::TextSingleLine | Qt::TextDontClip;

    // Un contour sombre pour rester lisible sur l'herbe comme sur l'eau.
    peintre.setPen(QColor(20, 20, 30));
    peintre.drawText(cadre.translated(-1, 0), options, commande.texte);
    peintre.drawText(cadre.translated(1, 0), options, commande.texte);
    peintre.drawText(cadre.translated(0, -1), options, commande.texte);
    peintre.drawText(cadre.translated(0, 1), options, commande.texte);
    peintre.setPen(Qt::white);
    peintre.drawText(cadre, options, commande.texte);
}

void ZoneJeu::dessinerInfos(QPainter &peintre, const QRect &carte)
{
    QFont police = font();
    police.setBold(true);
    police.setPixelSize(qMax(11, m_tailleCase * 3 / 8));
    peintre.setFont(police);

    const int marge = qMax(4, m_tailleCase / 4);
    const QRect bandeau(carte.left(), carte.top(), carte.width(),
                        peintre.fontMetrics().height() + marge);
    peintre.fillRect(bandeau, QColor(20, 22, 34, 205));
    peintre.setPen(Qt::white);
    peintre.drawText(bandeau.adjusted(marge, 0, -marge, 0),
                     Qt::AlignVCenter | Qt::AlignLeft | Qt::TextSingleLine, m_infos);
}

void ZoneJeu::dessinerDialogue(QPainter &peintre, const QRect &carte)
{
    QFont police = font();
    police.setPixelSize(qMax(12, m_tailleCase * 7 / 16));
    peintre.setFont(police);

    const int marge = qMax(4, m_tailleCase / 4);
    const int largeurTexte = carte.width() - 4 * marge;
    const QRect besoin = peintre.fontMetrics().boundingRect(
                QRect(0, 0, largeurTexte, carte.height()), Qt::TextWordWrap, m_dialogue);
    const int hauteurTexte = qMin(besoin.height(), carte.height() / 2);

    const QRect boite(carte.left() + marge, carte.bottom() - 3 * marge - hauteurTexte + 1,
                      carte.width() - 2 * marge, hauteurTexte + 2 * marge);

    peintre.setRenderHint(QPainter::Antialiasing, true);
    peintre.setPen(QPen(QColor(240, 240, 245), qMax(2, m_tailleCase / 16)));
    peintre.setBrush(QColor(20, 22, 34, 232));
    peintre.drawRoundedRect(boite, marge, marge);
    peintre.setRenderHint(QPainter::Antialiasing, false);

    peintre.setPen(Qt::white);
    peintre.drawText(boite.adjusted(marge, marge, -marge, -marge),
                     Qt::TextWordWrap | Qt::AlignLeft | Qt::AlignVCenter, m_dialogue);
}

// ---------------------------------------------------------------------------
//  La souris
// ---------------------------------------------------------------------------

void ZoneJeu::mousePressEvent(QMouseEvent *evenement)
{
    setFocus();

#if QT_VERSION >= QT_VERSION_CHECK(6, 0, 0)
    const QPoint position = evenement->position().toPoint() - m_origine;
#else
    const QPoint position = evenement->pos() - m_origine;
#endif
    if (m_tailleCase <= 0 || position.x() < 0 || position.y() < 0)
        return;

    const int x = position.x() / m_tailleCase;
    const int y = position.y() / m_tailleCase;
    if (estDansCarte(x, y))
        emit caseCliquee(x, y);
}
