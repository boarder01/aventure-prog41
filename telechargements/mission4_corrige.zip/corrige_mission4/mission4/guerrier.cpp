#include "guerrier.h"

Guerrier::Guerrier(QString nom, int x, int y)
    : Heros(nom, "guerrier", x, y, 14)
{
}
