#include "guerisseur.h"

Guerisseur::Guerisseur(QString nom, int x, int y)
    : Villageois(nom, "guerisseur", x, y, "Approchez, je soigne les blessures.")
    , m_soin(1)
{
}

int Guerisseur::soin()
{
    return m_soin;
}
