#include "potion.h"

Potion::Potion(int x, int y)
    : ObjetUtile("Potion", "potion", x, y, 5)
{
}
