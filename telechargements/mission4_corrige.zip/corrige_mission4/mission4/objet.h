#ifndef OBJET_H
#define OBJET_H

#include <QString>

// Un objet du jeu : son nom, son image, sa case, et s'il se trouve sur la carte.

class Objet
{
public:
    Objet(QString nom = "Objet", QString image = "coffre", int x = 0, int y = 0);

    bool estSurLaCarte();
    void ramasser();
    void poser(int x, int y);

    QString nom();
    QString image();
    int x();
    int y();

private:
    QString m_nom;
    QString m_image;
    int m_x;
    int m_y;
    bool m_surLaCarte;
};

#endif // OBJET_H
