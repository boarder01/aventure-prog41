#ifndef MARCHAND_H
#define MARCHAND_H

#include "villageois.h"

// Le marchand du village : il sait où se trouve la clé.

class Marchand : public Villageois
{
public:
    Marchand(QString nom = "Marchand", int x = 1, int y = 1);
};

#endif // MARCHAND_H
