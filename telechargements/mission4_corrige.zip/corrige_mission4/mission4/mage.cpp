#include "mage.h"

Mage::Mage(QString nom, int x, int y)
    : Heros(nom, "mage", x, y, 8)
{
}
