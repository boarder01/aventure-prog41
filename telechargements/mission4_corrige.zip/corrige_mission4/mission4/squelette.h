#ifndef SQUELETTE_H
#define SQUELETTE_H

#include "monstre.h"

// Un monstre rapide et fort.

class Squelette : public Monstre
{
public:
    Squelette(int x = 1, int y = 1);
    QString cri();
};

#endif // SQUELETTE_H
