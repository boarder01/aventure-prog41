#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

#include "chauvesouris.h"
#include "cle.h"
#include "guerisseur.h"
#include "guerrier.h"
#include "marchand.h"
#include "piece.h"
#include "potion.h"
#include "slime.h"
#include "squelette.h"

const int NB_SLIMES = 2;
const int NB_SQUELETTES = 2;
const int NB_POTIONS = 2;
const int NB_PIECES = 3;

// Mission 4 : un bestiaire et des objets. Sans référence ni pointeur, il faut
// un tableau par classe de monstre, et donc une boucle par tableau.

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void tourDeJeu();       // appelé par le moteur à chaque tour de jeu

private:
    bool voisines(int x1, int y1, int x2, int y2);
    bool caseOccupee(int x, int y);
    bool caseLibre(int x, int y);
    void crier(QString cri, int x, int y);

    Ui::MainWindow *ui;

    Guerrier m_heros;
    Marchand m_marchand;
    Guerisseur m_guerisseur;

    Slime m_slimes[NB_SLIMES];
    Squelette m_squelettes[NB_SQUELETTES];
    ChauveSouris m_chauveSouris;

    Arme m_epee;
    Potion m_potions[NB_POTIONS];
    Cle m_cle;
    Piece m_pieces[NB_PIECES];

    // Le cri du dernier monstre qui a mordu, affiché pendant quelques tours
    QString m_cri;
    int m_criX;
    int m_criY;
    int m_criTours;
};

#endif // MAINWINDOW_H
