#include "piece.h"

Piece::Piece(int x, int y)
    : ObjetUtile("Pièce", "piece", x, y, 5)
{
}
