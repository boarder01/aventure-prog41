#include "arme.h"

Arme::Arme(QString nom, QString image, int x, int y, int degats)
    : Objet(nom, image, x, y)
{
    m_degats = degats;
}

int Arme::degats()
{
    return m_degats;
}
