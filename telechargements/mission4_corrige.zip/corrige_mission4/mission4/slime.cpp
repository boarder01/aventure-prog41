#include "slime.h"

Slime::Slime(int x, int y)
    : Monstre("Slime", "slime", x, y, 3, 1, 3)
{
}

QString Slime::cri()
{
    return "Blob !";
}
