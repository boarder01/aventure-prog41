#include "marchand.h"

Marchand::Marchand(QString nom, int x, int y)
    : Villageois(nom, "marchand", x, y,
                 "Bonjour ! La clé des ruines est tombée près du rocher, de l'autre côté du pont.")
{
}
