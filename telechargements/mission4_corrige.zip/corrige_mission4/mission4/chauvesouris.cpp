#include "chauvesouris.h"

ChauveSouris::ChauveSouris(int x, int y)
    : Monstre("Chauve-souris", "chauve_souris", x, y, 2, 1, 1)
{
}

QString ChauveSouris::cri()
{
    return "Scriii !";
}
