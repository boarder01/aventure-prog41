#include "cle.h"

Cle::Cle(int x, int y)
    : ObjetUtile("Clé", "cle", x, y, 0)
{
}
