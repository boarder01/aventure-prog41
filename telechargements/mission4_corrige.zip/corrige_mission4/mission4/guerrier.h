#ifndef GUERRIER_H
#define GUERRIER_H

#include "heros.h"

// Un héros solide : 14 points de vie.

class Guerrier : public Heros
{
public:
    Guerrier(QString nom = "Guerrier", int x = 1, int y = 1);
};

#endif // GUERRIER_H
