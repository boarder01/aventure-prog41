#ifndef PERSONNAGE_H
#define PERSONNAGE_H

#include <QString>

// La classe mère de tous les personnages du jeu.
// m_x et m_y sont protégés (# en UML) : les classes filles y ont accès.

class Personnage
{
public:
    Personnage(QString nom = "Inconnu", QString image = "villageois",
               int x = 1, int y = 1, int vieMax = 10);
    ~Personnage();

    void deplacer(int dx, int dy);
    void recevoirDegats(int degats);
    void soigner(int points);
    bool estVivant();

    QString nom();
    QString image();
    int x();
    int y();
    int vie();
    int vieMax();

protected:
    int m_x;
    int m_y;

private:
    QString m_nom;
    QString m_image;
    int m_vie;
    int m_vieMax;
};

#endif // PERSONNAGE_H
