#include "squelette.h"

Squelette::Squelette(int x, int y)
    : Monstre("Squelette", "squelette", x, y, 6, 2, 2)
{
}

QString Squelette::cri()
{
    return "Clac clac !";
}
