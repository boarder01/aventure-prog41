#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void tourDeJeu();       // appelé par le moteur à chaque tour de jeu

private:
    Ui::MainWindow *ui;

    // Le héros : pour l'instant, deux simples variables.
    int m_herosX;
    int m_herosY;
};

#endif // MAINWINDOW_H
