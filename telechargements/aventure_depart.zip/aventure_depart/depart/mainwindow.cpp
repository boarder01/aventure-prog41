#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Position de départ du héros, en cases : (0, 0) est en haut à gauche.
    m_herosX = 4;
    m_herosY = 9;

    // À chaque tour de jeu, le moteur appelle notre fonction tourDeJeu().
    connect(ui->jeu, SIGNAL(nouveauTour()), this, SLOT(tourDeJeu()));
    ui->jeu->demarrer();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::tourDeJeu()
{
    // 1. Le clavier : le héros avance d'une case si la case visée est libre.
    if (ui->jeu->touche(Qt::Key_Right) && ui->jeu->estLibre(m_herosX + 1, m_herosY))
    {
        m_herosX = m_herosX + 1;
    }
    if (ui->jeu->touche(Qt::Key_Left) && ui->jeu->estLibre(m_herosX - 1, m_herosY))
    {
        m_herosX = m_herosX - 1;
    }
    if (ui->jeu->touche(Qt::Key_Down) && ui->jeu->estLibre(m_herosX, m_herosY + 1))
    {
        m_herosY = m_herosY + 1;
    }
    if (ui->jeu->touche(Qt::Key_Up) && ui->jeu->estLibre(m_herosX, m_herosY - 1))
    {
        m_herosY = m_herosY - 1;
    }

    // 2. Le dessin : le moteur vient d'effacer l'écran et de redessiner la
    //    carte. À nous de redessiner tout ce qui existe dans le jeu.
    ui->jeu->dessiner("heros", m_herosX, m_herosY);
}
