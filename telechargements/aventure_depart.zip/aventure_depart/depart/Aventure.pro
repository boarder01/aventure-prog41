QT += core gui widgets

TARGET = Aventure
TEMPLATE = app

SOURCES += \
    main.cpp \
    mainwindow.cpp

HEADERS += \
    mainwindow.h

FORMS += \
    mainwindow.ui

# Le moteur du jeu (livré, à ne pas modifier)
include(../moteur/moteur.pri)
